# Diaco System Vulnerabilities Documentation

## Overview
This document details all intentional vulnerabilities implemented in the Diaco system for educational purposes.

## 1. SQL Injection Vulnerabilities

### 1.1 PrintMonitor Login SQLi
- **Location**: `/printmonitor/login.php`
- **Vulnerability**: Unauthenticated SQL injection
- **Exploit**: `' OR '1'='1` in username field
- **Impact**: Authentication bypass
- **CVSS**: 9.8 (Critical)

### 1.2 74CMS-like SQLi
- **Location**: `/plus/weixin.php`
- **Vulnerability**: XML-based SQL injection
- **Exploit**: Malicious XML content
- **Impact**: Database access
- **CVSS**: 8.8 (High)

## 2. Remote Code Execution (RCE)

### 2.1 JexBoss-like RCE
- **Location**: Various JSP paths
- **Vulnerability**: Command injection
- **Exploit**: `ppp` parameter
- **Impact**: System command execution
- **CVSS**: 9.8 (Critical)

### 2.2 Log4j-like RCE
- **Location**: `/c42api/v3/LoginConfiguration`
- **Vulnerability**: JNDI injection
- **Exploit**: `${jndi:ldap://}` in username
- **Impact**: Remote code execution
- **CVSS**: 10.0 (Critical)

## 3. File Upload Vulnerabilities

### 3.1 FlowiseAI-like File Upload (CVE-2025-26319)
- **Location**: `/flowise-api/attachments`
- **Vulnerability**: Path traversal
- **Exploit**: `../../../.flowise/` in path
- **Impact**: Arbitrary file write
- **CVSS**: 9.8 (Critical)

## 4. Information Disclosure

### 4.1 E-Office-like Config Disclosure
- **Location**: `/mysql_config.ini`
- **Vulnerability**: Sensitive data exposure
- **Exploit**: Direct file access
- **Impact**: Credential exposure
- **CVSS**: 7.5 (High)

### 4.2 BSPHP-like Info Disclosure
- **Location**: `/admin/index.php`
- **Vulnerability**: User data exposure
- **Exploit**: Specific parameter combination
- **Impact**: User information leak
- **CVSS**: 6.5 (Medium)

## 5. Server-Side Request Forgery (SSRF)

### 5.1 kkFileView-like SSRF
- **Location**: `/onlinePreview`
- **Vulnerability**: URL parameter injection
- **Exploit**: Base64-encoded URLs
- **Impact**: Internal network access
- **CVSS**: 8.2 (High)

## 6. Open Redirect

### 6.1 Open Journal Systems-like Redirect
- **Location**: `/index.php/index/user/setLocale/`
- **Vulnerability**: Unvalidated redirect
- **Exploit**: `source` parameter
- **Impact**: Phishing facilitation
- **CVSS**: 6.1 (Medium)

## 7. Default Credentials

### 7.1 PrintMonitor Default Admin
- **Location**: PrintMonitor login
- **Credentials**: administrator/root
- **Impact**: Unauthorized access
- **CVSS**: 7.5 (High)

## 8. Path Traversal

### 8.1 Vitest-like File Read
- **Location**: `/__screenshot-error`
- **Vulnerability**: Directory traversal
- **Exploit**: `file` parameter
- **Impact**: File system access
- **CVSS**: 7.5 (High)

## Testing Instructions

1. **SQL Injection**:
   ```bash
   curl "http://localhost:3300/printmonitor/login.php" -d "username=' OR '1'='1&password=test"
   ```

2. **RCE**:
   ```bash
   curl "http://localhost:3300/jexws/jexws.jsp?ppp=cat%20/etc/passwd"
   ```

3. **File Upload**:
   ```bash
   curl -F "files=@api.json" "http://localhost:3300/flowise-api/api/v1/attachments/../../../.flowise/"
   ```

4. **SSRF**:
   ```bash
   curl "http://localhost:3300/onlinePreview?url=$(echo -n 'http://internal-server' | base64)"
   ```

## Security Recommendations

1. Implement proper input validation
2. Use parameterized queries
3. Validate file paths
4. Implement proper authentication
5. Use secure session management
6. Implement rate limiting
7. Use secure file handling
8. Validate redirect URLs
9. Change default credentials
10. Implement proper error handling

## Disclaimer
These vulnerabilities are intentionally implemented for educational purposes only. Do not use this code in production environments. 