// XSS Vulnerability
if (isset($_GET['q'])) {
    $search = $_GET['q'];
    echo "<h2>Search Results for: " . $search . "</h2>";
} 