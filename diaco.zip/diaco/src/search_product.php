<?php
// اتصال به دیتابیس (آسیب‌پذیر)
$mysqli = new mysqli('db', 'diaco', 'diaco_password', 'diaco_db');
if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}
$resultMessage = '';
if (isset($_GET['q'])) {
    $q = $_GET['q'];
    // آسیب‌پذیر به SQL Injection
    $sql = "SELECT name FROM products WHERE name = '$q' OR id = '$q'";
    $result = $mysqli->query($sql);
    if ($result === false) {
        die('Error in query: ' . $mysqli->error);
    }
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $resultMessage = "Product: " . htmlspecialchars($row['name']);
    } else {
        $resultMessage = "No product found.";
    }
}
$mysqli->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Vulnerable Product Search</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f2f2f2; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .container { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 400px; }
        h2 { text-align: center; margin-bottom: 20px; }
        label { margin-bottom: 5px; font-weight: bold; }
        input[type="text"] { width: 100%; padding: 12px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        input[type="submit"] { width: 100%; padding: 12px; background: #4CAF50; color: #fff; border: none; border-radius: 4px; cursor: pointer; margin-top: 10px; }
        input[type="submit"]:hover { background: #45a049; }
        .result { margin-top: 20px; padding: 10px; border: 1px solid #ccc; border-radius: 4px; background: #e9ecef; text-align: center; max-width: 300px; word-wrap: break-word; margin: 0 auto; }
        .danger { color: red; text-align: center; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Vulnerable Product Search</h2>
        <form method="get" action="">
            <label for="q">Product name or ID:</label>
            <input type="text" id="q" name="q" required>
            <input type="submit" value="Search">
        </form>
        <div class="result">
            <?php if (!empty($resultMessage)) { echo htmlspecialchars($resultMessage); } ?>
        </div>
        <div class="danger">This page is intentionally vulnerable to SQL Injection and RCE via SQLi (INTO OUTFILE).<br>Use only for educational purposes!</div>
    </div>
</body>
</html> 