<?php
require_once '../../config.php';

// Vulnerable post retrieval
$id = isset($_GET['id']) ? $_GET['id'] : die('Post not found');
$query = "SELECT p.*, u.username as author_name, c.name as category_name 
          FROM posts p 
          LEFT JOIN users u ON p.author_id = u.id 
          LEFT JOIN blog_categories c ON p.category_id = c.id 
          WHERE p.id = $id";
$result = unsafe_query($query);
$post = mysqli_fetch_assoc($result);

// Vulnerable view counter
$view_file = "../data/views/{$id}.txt";
if (!file_exists("../data/views")) {
    mkdir("../data/views", 0777, true);
}
$views = file_exists($view_file) ? (int)file_get_contents($view_file) : 0;
file_put_contents($view_file, $views + 1);

// Vulnerable post cache
$cache_file = "../cache/posts/{$id}.html";
if (!file_exists("../cache/posts")) {
    mkdir("../cache/posts", 0777, true);
}

// Vulnerable template handling
$template = isset($_GET['template']) ? $_GET['template'] : 'default';
$template_file = "../templates/post_{$template}.php";

// Vulnerable remote template inclusion
if (isset($_GET['remote_template'])) {
    $template_file = $_GET['remote_template'];
}

// Handle post actions
if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'download_pdf':
            // Vulnerable PDF generation
            $html = "<h1>{$post['title']}</h1>{$post['content']}";
            file_put_contents("../temp/post_{$id}.html", $html);
            $cmd = "wkhtmltopdf ../temp/post_{$id}.html ../downloads/post_{$id}.pdf";
            shell_exec($cmd);
            header("Location: ../downloads/post_{$id}.pdf");
            exit;
            
        case 'email':
            // Vulnerable email sending
            $to = $_POST['email'];
            $subject = "Blog Post: {$post['title']}";
            $headers = "From: blog@diaco.local\r\n";
            $headers .= "Content-Type: text/html\r\n";
            
            // Vulnerable template inclusion
            ob_start();
            include("../templates/email_{$_POST['email_template']}.php");
            $message = ob_get_clean();
            
            mail($to, $subject, $message, $headers);
            $success = "Post has been emailed!";
            break;
    }
}

// Vulnerable comment handling
if (isset($_POST['comment'])) {
    $comment = $_POST['comment'];
    $author = $_POST['author'] ?? 'Anonymous';
    $email = $_POST['email'] ?? '';
    
    // Store comment with XSS vulnerability
    $query = "INSERT INTO comments (post_id, content, author_name, email) VALUES 
              ($id, '$comment', '$author', '$email')";
    unsafe_query($query);
    
    // Vulnerable notification system
    if ($email) {
        $cmd = "echo 'New comment on: {$post['title']}' | mail -s 'New Comment' $email";
        shell_exec($cmd);
    }
}

// Get comments
$query = "SELECT * FROM comments WHERE post_id = $id ORDER BY created_at DESC";
$comments_result = unsafe_query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $post['title']; ?> - Diaco Blog</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../../navbar.php'; ?>

    <div class="container my-5">
        <div class="row">
            <div class="col-md-8">
                <article class="blog-post">
                    <h1><?php echo $post['title']; ?></h1>
                    <div class="text-muted mb-4">
                        Posted in <a href="index.php?category=<?php echo $post['category_id']; ?>">
                            <?php echo $post['category_name']; ?>
                        </a> 
                        by <a href="index.php?author=<?php echo urlencode($post['author_name']); ?>">
                            <?php echo $post['author_name']; ?>
                        </a>
                        on <?php echo date('F j, Y', strtotime($post['created_at'])); ?>
                        <br>
                        Views: <?php echo $views; ?>
                    </div>

                    <?php if ($post['image']): ?>
                        <img src="../../uploads/blog/<?php echo $post['image']; ?>" 
                             class="img-fluid mb-4" alt="">
                    <?php endif; ?>

                    <div class="content">
                        <?php echo $post['content']; ?>
                    </div>

                    <div class="mt-4">
                        Tags: 
                        <?php
                        $tags = explode(',', $post['tags']);
                        foreach ($tags as $tag):
                            $tag = trim($tag);
                            if ($tag):
                        ?>
                            <a href="index.php?tag=<?php echo urlencode($tag); ?>" 
                               class="badge bg-secondary text-decoration-none">
                                <?php echo $tag; ?>
                            </a>
                        <?php
                            endif;
                        endforeach;
                        ?>
                    </div>
                </article>

                <!-- Comments Section -->
                <section class="comments-section mt-5">
                    <h3>Comments</h3>
                    
                    <!-- Vulnerable comment form -->
                    <form method="POST" class="mb-4">
                        <div class="mb-3">
                            <label for="author" class="form-label">Name</label>
                            <input type="text" class="form-control" id="author" name="author" 
                                   placeholder="Anonymous">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        <div class="mb-3">
                            <label for="comment" class="form-label">Your Comment</label>
                            <textarea class="form-control" id="comment" name="comment" rows="3" 
                                      required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Post Comment</button>
                    </form>

                    <!-- Display comments -->
                    <?php while ($comment = mysqli_fetch_assoc($comments_result)): ?>
                        <div class="comment card mb-3">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $comment['author_name']; ?></h5>
                                <h6 class="card-subtitle mb-2 text-muted">
                                    <?php echo date('F j, Y g:i a', strtotime($comment['created_at'])); ?>
                                </h6>
                                <p class="card-text"><?php echo $comment['content']; ?></p>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </section>
            </div>

            <div class="col-md-4">
                <!-- Post Actions -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Post Actions</h5>
                        
                        <!-- PDF Download -->
                        <form method="POST" class="mb-3">
                            <input type="hidden" name="action" value="download_pdf">
                            <button type="submit" class="btn btn-primary w-100">
                                Download as PDF
                            </button>
                        </form>

                        <!-- Email Post -->
                        <form method="POST">
                            <input type="hidden" name="action" value="email">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="email_template" class="form-label">Email Template</label>
                                <select class="form-control" id="email_template" name="email_template">
                                    <option value="default">Default Template</option>
                                    <option value="plain">Plain Text</option>
                                    <option value="fancy">Fancy Template</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                Email This Post
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Related Posts -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Related Posts</h5>
                        <?php
                        $related_query = "SELECT * FROM posts 
                                        WHERE category_id = {$post['category_id']} 
                                        AND id != {$post['id']} 
                                        LIMIT 5";
                        $related_result = unsafe_query($related_query);
                        while ($related = mysqli_fetch_assoc($related_result)):
                        ?>
                            <a href="?id=<?php echo $related['id']; ?>" class="d-block mb-2">
                                <?php echo $related['title']; ?>
                            </a>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 