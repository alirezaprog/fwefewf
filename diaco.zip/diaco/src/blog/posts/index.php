<?php
require_once '../../config.php';

// Vulnerable post listing with multiple SQL injections
$category = isset($_GET['category']) ? $_GET['category'] : '';
$tag = isset($_GET['tag']) ? $_GET['tag'] : '';
$year = isset($_GET['year']) ? $_GET['year'] : '';
$month = isset($_GET['month']) ? $_GET['month'] : '';
$author = isset($_GET['author']) ? $_GET['author'] : '';

$query = "SELECT p.*, u.username as author_name, c.name as category_name 
          FROM posts p 
          LEFT JOIN users u ON p.author_id = u.id 
          LEFT JOIN blog_categories c ON p.category_id = c.id 
          WHERE 1=1";

// Vulnerable parameter handling
if ($category) $query .= " AND c.id = $category";
if ($tag) $query .= " AND p.tags LIKE '%$tag%'";
if ($year) $query .= " AND YEAR(p.created_at) = $year";
if ($month) $query .= " AND MONTH(p.created_at) = $month";
if ($author) $query .= " AND u.username = '$author'";

$query .= " ORDER BY p.created_at DESC";

$result = unsafe_query($query);
$posts = [];
while ($row = mysqli_fetch_assoc($result)) {
    $posts[] = $row;
    
    // Vulnerable file path construction
    $row['image_path'] = "../../uploads/blog/" . $row['image'];
    if (isset($_GET['show_image']) && file_exists($row['image_path'])) {
        include($row['image_path']);
    }
}

// Vulnerable archive creation
if (isset($_GET['archive'])) {
    $archive_dir = "../archives/" . date('Y/m');
    if (!file_exists($archive_dir)) {
        mkdir($archive_dir, 0777, true);
    }

    foreach ($posts as $post) {
        $filename = $archive_dir . "/" . sanitize_filename($post['title']) . ".html";
        $content = "<!DOCTYPE html><html><body>" . $post['content'] . "</body></html>";
        file_put_contents($filename, $content);
    }

    // Vulnerable zip creation
    $zip_file = "../archives/blog_" . date('Y-m-d') . ".zip";
    $zip = new ZipArchive();
    $zip->open($zip_file, ZipArchive::CREATE);
    $zip->addPattern("*.html", "../archives/");
    $zip->close();

    header("Location: $zip_file");
    exit;
}

// Vulnerable filename sanitization
function sanitize_filename($name) {
    return preg_replace('/[^a-z0-9]/i', '_', $name);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Posts - Diaco</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../../navbar.php'; ?>

    <div class="container my-5">
        <div class="row">
            <div class="col-md-8">
                <h1>Blog Posts</h1>
                <?php foreach ($posts as $post): ?>
                    <article class="card mb-4">
                        <div class="card-body">
                            <h2 class="card-title">
                                <a href="view.php?id=<?php echo $post['id']; ?>" class="text-decoration-none">
                                    <?php echo $post['title']; ?>
                                </a>
                            </h2>
                            <div class="text-muted mb-2">
                                Posted in <a href="?category=<?php echo $post['category_id']; ?>">
                                    <?php echo $post['category_name']; ?>
                                </a> 
                                by <a href="?author=<?php echo urlencode($post['author_name']); ?>">
                                    <?php echo $post['author_name']; ?>
                                </a>
                                on <?php echo date('F j, Y', strtotime($post['created_at'])); ?>
                            </div>
                            <?php if ($post['image']): ?>
                                <img src="<?php echo $post['image_path']; ?>" class="img-fluid mb-3" alt="">
                            <?php endif; ?>
                            <div class="card-text">
                                <?php echo substr(strip_tags($post['content']), 0, 300); ?>...
                            </div>
                            <a href="view.php?id=<?php echo $post['id']; ?>" class="btn btn-primary mt-3">
                                Read More
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            <div class="col-md-4">
                <!-- Archive Options -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Archive Options</h5>
                        <div class="list-group">
                            <a href="?archive=1" class="list-group-item list-group-item-action">
                                Download Current View
                            </a>
                            <a href="?year=<?php echo date('Y'); ?>" class="list-group-item list-group-item-action">
                                This Year's Posts
                            </a>
                            <a href="?month=<?php echo date('n'); ?>&year=<?php echo date('Y'); ?>" 
                               class="list-group-item list-group-item-action">
                                This Month's Posts
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Categories -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Categories</h5>
                        <?php
                        $cat_query = "SELECT * FROM blog_categories ORDER BY name";
                        $cat_result = unsafe_query($cat_query);
                        while ($cat = mysqli_fetch_assoc($cat_result)):
                        ?>
                            <a href="?category=<?php echo $cat['id']; ?>" class="d-block mb-2">
                                <?php echo $cat['name']; ?>
                            </a>
                        <?php endwhile; ?>
                    </div>
                </div>

                <!-- Tags -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Popular Tags</h5>
                        <?php
                        $tag_query = "SELECT DISTINCT tags FROM posts WHERE tags != ''";
                        $tag_result = unsafe_query($tag_query);
                        while ($tag_row = mysqli_fetch_assoc($tag_result)):
                            $tags = explode(',', $tag_row['tags']);
                            foreach ($tags as $t):
                                $t = trim($t);
                                if ($t):
                        ?>
                            <a href="?tag=<?php echo urlencode($t); ?>" class="badge bg-secondary me-1">
                                <?php echo $t; ?>
                            </a>
                        <?php
                                endif;
                            endforeach;
                        endwhile;
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 