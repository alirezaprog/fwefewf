<?php
require_once '../../config.php';

// Vulnerable category listing with SQL injection
$category = isset($_GET['cat']) ? $_GET['cat'] : '';
$query = "SELECT * FROM blog_categories";
if ($category) {
    $query .= " WHERE name LIKE '%$category%'";
}
$categories = unsafe_query($query);

// Vulnerable file operations
if (isset($_GET['export'])) {
    $format = $_GET['format'] ?? 'json';
    $filename = "../data/exports/categories_" . date('Y-m-d') . ".$format";
    
    if (!file_exists("../data/exports")) {
        mkdir("../data/exports", 0777, true);
    }

    $data = [];
    while ($row = mysqli_fetch_assoc($categories)) {
        $data[] = $row;
    }

    file_put_contents($filename, json_encode($data));
    header("Location: $filename");
    exit;
}

// CVE-2021-41763: Local File Inclusion in Category Template
if (isset($_GET['category'])) {
    $category = $_GET['category'];
    
    // Intentionally vulnerable: Direct file inclusion
    $template_file = "templates/categories/" . $category . ".php";
    if (file_exists($template_file)) {
        include($template_file);
    } else {
        echo "<div class='alert alert-warning'>Category template not found.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Categories - Diaco</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../../navbar.php'; ?>

    <div class="container my-5">
        <div class="row">
            <div class="col-md-8">
                <h1>Blog Categories</h1>
                <div class="list-group mt-4">
                    <?php while ($category = mysqli_fetch_assoc($categories)): ?>
                        <a href="../posts/index.php?category=<?php echo urlencode($category['id']); ?>" 
                           class="list-group-item list-group-item-action">
                            <h5 class="mb-1"><?php echo $category['name']; ?></h5>
                            <p class="mb-1"><?php echo $category['description']; ?></p>
                            <small>Posts: <?php echo $category['post_count']; ?></small>
                        </a>
                    <?php endwhile; ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Search Categories</h5>
                        <form method="GET">
                            <div class="mb-3">
                                <input type="text" name="cat" class="form-control" placeholder="Search...">
                            </div>
                            <button type="submit" class="btn btn-primary">Search</button>
                            <a href="?export=1" class="btn btn-secondary">Export Categories</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 