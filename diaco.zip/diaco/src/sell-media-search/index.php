<?php
// CVE-2019-6112: Cross-Site Scripting in Search Functionality
// This file intentionally contains an XSS vulnerability for educational purposes

require_once '../config.php';

// Intentionally vulnerable: No input sanitization
$search_term = isset($_GET['keyword']) ? $_GET['keyword'] : '';

// Initialize results array
$results = [];

// Only perform search if we have a search term
if (!empty($search_term)) {
    try {
        // Check if tables exist
        $tables_check = $conn->query("SHOW TABLES LIKE 'products'");
        if ($tables_check->num_rows == 0) {
            // Create tables if they don't exist
            $conn->query("CREATE TABLE IF NOT EXISTS products (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                description TEXT,
                price DECIMAL(10,2),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
            
            $conn->query("CREATE TABLE IF NOT EXISTS search_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                term TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
            
            // Insert sample data
            $conn->query("INSERT INTO products (name, description, price) VALUES
                ('Sample Product 1', 'This is a sample product description', 99.99),
                ('Sample Product 2', 'Another sample product description', 149.99),
                ('Test Product', 'A test product for search functionality', 199.99)");
        }
        
        // Store search term in database without sanitization (intentionally vulnerable)
        $stmt = $conn->prepare("INSERT INTO search_history (term, timestamp) VALUES (?, NOW())");
        if ($stmt) {
            $stmt->bind_param("s", $search_term);
            $stmt->execute();
        }
        
        // Perform search (intentionally vulnerable to SQL injection)
        $query = "SELECT * FROM products WHERE name LIKE ? OR description LIKE ?";
        $stmt = $conn->prepare($query);
        if ($stmt) {
            $search_pattern = "%$search_term%";
            $stmt->bind_param("ss", $search_pattern, $search_pattern);
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($row = $result->fetch_assoc()) {
                $results[] = $row;
            }
        }
    } catch (Exception $e) {
        // Log error but don't expose it to user
        error_log("Search error: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Sell Media Search</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <h1>Sell Media Search</h1>
        
        <!-- Intentionally vulnerable search form -->
        <form method="GET" action="index.php">
            <input type="text" 
                   id="sell-media-search-text" 
                   class="sell-media-search-text" 
                   name="keyword" 
                   value="<?php echo htmlspecialchars($search_term); ?>" 
                   placeholder="Search products...">
            <button type="submit">Search</button>
        </form>

        <!-- Intentionally vulnerable results display -->
        <?php if (!empty($search_term)): ?>
            <div class="search-results">
                <h2>Search Results for: <?php echo $search_term; ?></h2>
                <?php if (empty($results)): ?>
                    <p>No results found for "<?php echo $search_term; ?>"</p>
                <?php else: ?>
                    <ul>
                    <?php foreach ($results as $product): ?>
                        <li>
                            <h3><?php echo $product['name']; ?></h3>
                            <p><?php echo $product['description']; ?></p>
                            <p class="price">Price: $<?php echo $product['price']; ?></p>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html> 