<?php
// Database configuration
$db_host = getenv('DB_HOST') ?: 'db';
$db_user = getenv('DB_USER') ?: 'diaco';
$db_password = getenv('DB_PASSWORD') ?: 'diaco_password';
$db_name = getenv('DB_NAME') ?: 'diaco_db';

// Create connection
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set charset to utf8mb4
mysqli_set_charset($conn, "utf8mb4");

// Constants
define('UPLOAD_DIR', 'uploads/');
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'php']); // Intentionally allowing PHP files

// Intentionally vulnerable functions
function unsafe_include($file) {
    include($file);
}

// Function for unsafe queries (intentionally vulnerable)
function unsafe_query($sql) {
    global $conn;
    return mysqli_query($conn, $sql);
}

function unsafe_redirect($url) {
    header("Location: " . $url);
    exit();
}

// Intentionally missing input sanitization
function get_post_param($param) {
    return $_POST[$param] ?? '';
}

function get_get_param($param) {
    return $_GET[$param] ?? '';
}

// Intentionally vulnerable file upload function
function handle_file_upload($file) {
    $target_file = UPLOAD_DIR . basename($file["name"]);
    move_uploaded_file($file["tmp_name"], $target_file);
    return $target_file;
}

// Intentionally vulnerable command execution
function execute_command($cmd) {
    return shell_exec($cmd);
}

// Debug mode (intentionally vulnerable)
if (isset($_GET['debug'])) {
    echo "Database connection info:<br>";
    echo "Host: $db_host<br>";
    echo "User: $db_user<br>";
    echo "Password: $db_password<br>";
    echo "Database: $db_name<br>";
}

// Error reporting (intentionally vulnerable)
error_reporting(E_ALL);
ini_set('display_errors', 1);
?> 