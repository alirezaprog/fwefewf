// CVE-2021-41765: SSRF in Image Processing
if (isset($_GET['image_url'])) {
    $image_url = $_GET['image_url'];
    
    // Intentionally vulnerable: No URL validation
    $image_data = file_get_contents($image_url);
    
    // Process image without validation
    $image = imagecreatefromstring($image_data);
    if ($image) {
        // Save processed image
        $output_file = 'processed_' . basename($image_url);
        imagejpeg($image, 'uploads/' . $output_file);
        imagedestroy($image);
        
        echo "<div class='alert alert-success'>Image processed successfully!</div>";
    }
} 