<?php
session_start();

// Check if user is logged in and has secure session
if (!isset($_SESSION['printmonitor_user']) || !isset($_SESSION['printmonitor_secure_session']) || !isset($_COOKIE['MANTIS_secure_session'])) {
    header('Location: login.php');
    exit();
}

$user = $_SESSION['printmonitor_user'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PrintMonitor Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .dashboard-container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .welcome {
            margin: 0;
        }
        .logout-btn {
            padding: 8px 15px;
            background-color: #dc3545;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            margin: 0 0 10px 0;
            color: #666;
        }
        .stat-card .value {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        .activity-section {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .activity-section h2 {
            margin: 0 0 20px 0;
            color: #333;
        }
        .activity-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .activity-item {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .activity-item:last-child {
            border-bottom: none;
        }
        .default-cred-warning {
            background-color: #fff3cd;
            border: 1px solid #ffeeba;
            color: #856404;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php if ($user['username'] === 'administrator'): ?>
        <div class="default-cred-warning">
            <strong>Warning:</strong> You are using default administrator credentials (administrator/root). 
            Please change these credentials immediately to secure your system.
        </div>
        <?php endif; ?>

        <div class="header">
            <h1 class="welcome">Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h1>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Prints</h3>
                <div class="value">150</div>
            </div>
            <div class="stat-card">
                <h3>Active Users</h3>
                <div class="value">45</div>
            </div>
            <div class="stat-card">
                <h3>Printers</h3>
                <div class="value">12</div>
            </div>
            <div class="stat-card">
                <h3>System Uptime</h3>
                <div class="value">89%</div>
            </div>
        </div>

        <div class="activity-section">
            <h2>Recent Activity</h2>
            <ul class="activity-list">
                <li class="activity-item">User "john_doe" printed document "report.pdf"</li>
                <li class="activity-item">Printer "HP-LaserJet" went offline</li>
                <li class="activity-item">New user "jane_smith" registered</li>
                <li class="activity-item">System backup completed successfully</li>
                <li class="activity-item">Printer "Canon-PIXMA" requires maintenance</li>
            </ul>
        </div>
    </div>
</body>
</html> 