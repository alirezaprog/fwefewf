<?php
// CVE-2018-7282: Time-based SQL Injection in PrintMonitor Login
// This file intentionally contains a SQL injection vulnerability for educational purposes

session_start();

// Database connection
$db = new mysqli('mysql', 'printmonitor', 'printmonitor123', 'printmonitor');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Vulnerable SQL query - SQL Injection possible
    $query = "SELECT * FROM printmonitor_users WHERE username = '$username' AND password = '$password'";
    $result = $db->query($query);
    
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Set session variables
        $_SESSION['printmonitor_user'] = $user;
        $_SESSION['printmonitor_secure_session'] = 1;
        
        // Set secure session cookie
        setcookie('MANTIS_secure_session', '1', 0, '/', '', false, true);
        
        // Redirect to dashboard
        header('Location: dashboard.php');
        exit();
    } else {
        $error = "Invalid credentials";
    }
}

// Check for default credentials warning
$show_default_cred_warning = false;
if (isset($_POST['username']) && $_POST['username'] === 'administrator') {
    $show_default_cred_warning = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PrintMonitor Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f5f5f5;
        }
        .login-container {
            background-color: white;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header h1 {
            color: #333;
            margin: 0;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #666;
        }
        .form-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 3px;
            box-sizing: border-box;
        }
        .submit-btn {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        .submit-btn:hover {
            background-color: #0056b3;
        }
        .error {
            color: #dc3545;
            margin-bottom: 20px;
            text-align: center;
        }
        .warning {
            color: #856404;
            background-color: #fff3cd;
            border: 1px solid #ffeeba;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 3px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>PrintMonitor</h1>
            <p>Please login to continue</p>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($show_default_cred_warning): ?>
            <div class="warning">
                Warning: You are using default administrator credentials. Please change them immediately after login.
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="submit-btn">Login</button>
        </form>
    </div>
</body>
</html> 