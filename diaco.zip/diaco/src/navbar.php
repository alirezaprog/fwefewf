<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="/">
            <img src="/assets/images/logo.svg" alt="Diaco Logo">
            <span>Diaco</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/"><i class="fas fa-home"></i> Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/blog/posts/"><i class="fas fa-blog"></i> Blog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/services.php"><i class="fas fa-cogs"></i> Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/contact.php"><i class="fas fa-envelope"></i> Contact</a>
                </li>
            </ul>
        </div>
    </div>
</nav> 