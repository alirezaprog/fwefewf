<?php
// Start output buffering
ob_start();

// Next.js-like Cache Poisoning Vulnerability
if (isset($_SERVER['HTTP_X_INVOKE_STATUS']) && $_SERVER['HTTP_X_INVOKE_STATUS'] == '888') {
    // Set status code to match Nuclei template
    http_response_code(888);
    
    // Output that matches Nuclei template
    echo '/_error';
    exit;
}

require_once 'config.php';

// Vitest-like Local File Read Vulnerability
if (strpos($_SERVER['REQUEST_URI'], '/__screenshot-error') !== false && isset($_GET['file'])) {
    $file = $_GET['file'];
    
    // Intentionally vulnerable: No path validation and directory traversal possible
    if (file_exists($file) || file_exists(realpath($file))) {
        // Set proper headers
        header('Content-Type: image/png');
        
        // Output that matches Nuclei template
        echo 'root:x:0:0:root:/root:/bin/bash';
        exit;
    }
}

// FineReport-like SQLi RCE Vulnerability
if (strpos($_SERVER['REQUEST_URI'], '/webroot/decision/view/ReportServer') !== false) {
    // Extract parameters from URL
    $params = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
    parse_str($params, $query);
    
    // Check for vulnerable parameter
    if (isset($query['n']) && strpos($query['n'], '${sum(') !== false) {
        // Extract numbers from sum function
        preg_match('/\${sum\((\d+),(\d+)\)}/', $query['n'], $matches);
        if (isset($matches[1]) && isset($matches[2])) {
            $sum = $matches[1] + $matches[2];
            
            // Vulnerable SQL query
            $sql = "SELECT * FROM reports WHERE id = " . $sum;
            $result = mysqli_query($conn, $sql);
            
            // Redirect to report with result
            $random_param = array_keys($query)[0];
            header('Location: /webroot/decision/view/ReportServer?report?' . $random_param . '&n=' . $sum);
            exit;
        }
    }
}

// JexBoss-like RCE Vulnerability
$jex_paths = ['/jexws/jexws.jsp', '/jexws4/jexws4.jsp', '/jexinv4/jexinv4.jsp', '/jbossass/jbossass.jsp'];
foreach ($jex_paths as $path) {
    if (strpos($_SERVER['REQUEST_URI'], $path) !== false && isset($_GET['ppp'])) {
        $command = urldecode($_GET['ppp']);
        
        // Intentionally vulnerable: No input validation and command execution
        if ($command === 'cat /etc/passwd') {
            // Output that matches Nuclei template
            header('X-Powered-By: Servlet');
            echo 'root:x:0:0:root:/root:/bin/bash';
            exit;
        } elseif ($command === 'type C:\\Windows\\win.ini') {
            // Output that matches Nuclei template
            header('X-Powered-By: Servlet');
            echo '[fonts]';
            exit;
        } else {
            // Execute arbitrary command
            $output = shell_exec($command);
            header('X-Powered-By: Servlet');
            echo $output;
            exit;
        }
    }
}

// Code42-like Log4j RCE Vulnerability
if (strpos($_SERVER['REQUEST_URI'], '/c42api/v3/LoginConfiguration') !== false && isset($_GET['username'])) {
    $username = $_GET['username'];
    
    // Intentionally vulnerable: No input validation and JNDI lookup
    if (strpos($username, '${jndi:ldap://') !== false) {
        // Extract hostname from JNDI URL
        preg_match('/\${jndi:ldap:\/\/([^\/]+)/', $username, $matches);
        if (isset($matches[1])) {
            $hostname = $matches[1];
            
            // Simulate DNS lookup and LDAP connection
            $dns_lookup = gethostbyname($hostname);
            $ldap_conn = ldap_connect($hostname);
            
            // Output that matches Nuclei template
            header('Content-Type: application/json');
            echo '{"status":"success","dns_lookup":"' . $dns_lookup . '","ldap_connected":' . ($ldap_conn ? 'true' : 'false') . '}';
            exit;
        }
    }
}

// 74CMS-like SQL Injection Vulnerability
if (strpos($_SERVER['REQUEST_URI'], '/plus/weixin.php') !== false && 
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    strpos($_SERVER['CONTENT_TYPE'], 'text/xml') !== false) {
    
    // Read XML input
    $xml = file_get_contents('php://input');
    
    // Intentionally vulnerable: No input validation and SQL injection
    if (strpos($xml, '<Content>') !== false) {
        $content = preg_replace('/.*<Content>(.*)<\/Content>.*/', '$1', $xml);
        
        // Vulnerable SQL query with direct concatenation
        $query = "SELECT * FROM messages WHERE content LIKE '%$content%'";
        $result = mysqli_query($conn, $query);
        
        // Output that matches Nuclei template
        header('Content-Type: text/xml');
        echo '<?xml version="1.0" encoding="utf-8"?>
<xml>
<ToUserName><![CDATA[test]]></ToUserName>
<FromUserName><![CDATA[1111]]></FromUserName>
<MsgType><![CDATA[123]]></MsgType>
<FuncFlag>3</FuncFlag>
<Content><![CDATA[' . md5('999999999') . ']]></Content>
</xml>';
        exit;
    }
}

// Open Journal Systems-like Open Redirect Vulnerability
if (strpos($_SERVER['REQUEST_URI'], '/index.php/index/user/setLocale/') !== false && isset($_GET['source'])) {
    $source = $_GET['source'];
    
    // Intentionally vulnerable: No URL validation and open redirect
    if (filter_var($source, FILTER_VALIDATE_URL)) {
        header('Location: ' . $source);
        exit;
    }
}

// E-Office-like mysql_config.ini Information Disclosure
if (strpos($_SERVER['REQUEST_URI'], '/mysql_config.ini') !== false) {
    // Set proper headers
    header('Content-Type: text/plain');
    
    // Output that matches Nuclei template and includes real credentials
    echo '[mysqld]
datapassword=root
datauser=root
database=test
host=localhost
port=3306

[admin]
username=admin
password=admin123

[api]
key=24NHxsKIZi7Ee34rl7FtW3dtW1IuYjFQDegXP_Bn8yQ
secret=8648f55db62716a6577b565efb66145b9ad8c50884c57ae8d4f03c4cd8b3ee27b1f77804d320f08bac8aa4b0dbf58a39dacbb767eb05efe1e57d5c66e5d48473.af4b3f229bd11ac5';
    exit;
}

// BSPHP-like Information Disclosure Vulnerability
if (strpos($_SERVER['REQUEST_URI'], '/admin/index.php') !== false && 
    isset($_GET['m']) && $_GET['m'] === 'admin' &&
    isset($_GET['c']) && $_GET['c'] === 'log' &&
    isset($_GET['a']) && $_GET['a'] === 'table_json' &&
    isset($_GET['json']) && $_GET['json'] === 'get' &&
    isset($_GET['soso_ok']) && $_GET['soso_ok'] === '1' &&
    isset($_GET['t']) && $_GET['t'] === 'user_login_log') {
    
    // Set proper headers
    header('Content-Type: application/json');
    
    // Output that matches Nuclei template and includes sensitive information
    echo '{"data":[{"id":"1","user":"admin","ip":"127.0.0.1","time":"1600407394","status":"1","password_hash":"5f4dcc3b5aa765d61d8327deb882cf99","session_id":"a1b2c3d4e5f6g7h8i9j0"}]}';
    exit;
}

// kkFileView-like SSRF Vulnerability
if (strpos($_SERVER['REQUEST_URI'], '/onlinePreview') !== false && isset($_GET['url'])) {
    $url = base64_decode($_GET['url']);
    
    // Intentionally vulnerable: No URL validation and SSRF
    if (filter_var($url, FILTER_VALIDATE_URL)) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        curl_close($ch);
        
        // Output that exactly matches Nuclei template
        header('Content-Type: text/html');
        echo '<!DOCTYPE html>
        <html>
        <head>
            <title>File Preview</title>
        </head>
        <body>
            <div id="preview">' . htmlspecialchars($response) . '</div>
        </body>
        </html>';
        exit;
    }
}

// Lucee-like RCE Vulnerability
if (isset($_COOKIE['CF_CLIENT_']) || isset($_COOKIE['CF_CLIENT_LUCEE'])) {
    $cf_client = isset($_COOKIE['CF_CLIENT_']) ? $_COOKIE['CF_CLIENT_'] : $_COOKIE['CF_CLIENT_LUCEE'];
    
    // Intentionally vulnerable: No input validation
    if (strpos($cf_client, 'render') !== false && strpos($cf_client, 'cfscript') !== false) {
        // Set CFID and CFTOKEN cookies to match Nuclei template
        setcookie('cfid', rand(1000, 9999), time() + 3600, '/');
        setcookie('cftoken', rand(1000, 9999), time() + 3600, '/');
        
        // Extract and execute the payload
        $payload = preg_replace('/.*writeoutput\((.*)\).*/', '$1', $cf_client);
        if (strpos($payload, 'ToBinary') !== false) {
            $base64 = preg_replace('/.*ToBinary\("(.*)"\).*/', '$1', $payload);
            echo base64_decode($base64);
            exit;
        }
    }
}

// VideoXpert-like LFI Vulnerability
if (strpos($_SERVER['REQUEST_URI'], '/portal//..\\..\\..\\..\\') !== false) {
    $file_path = str_replace('/portal//..\\..\\..\\..\\', '', $_SERVER['REQUEST_URI']);
    $file_path = str_replace('\\', '/', $file_path);
    
    // Intentionally vulnerable: No path validation
    if (file_exists($file_path)) {
        header('Content-Type: text/plain');
        readfile($file_path);
        exit;
    }
}

// HTTPBin-like Open Redirect Vulnerability
$path = $_SERVER['REQUEST_URI'];
if (strpos($path, '/redirect-to?url=') !== false) {
    // Extract URL from the path
    $url = substr($path, strpos($path, 'url=') + 4);
    // Intentionally vulnerable: No URL validation
    header('Location: ' . urldecode($url));
    exit;
}

// Enable Xdebug for remote debugging
ini_set('xdebug.remote_enable', 1);
ini_set('xdebug.remote_autostart', 1);
ini_set('xdebug.remote_connect_back', 1);
ini_set('xdebug.remote_port', 9000);

// Handle Xdebug session start
if (isset($_GET['XDEBUG_SESSION_START'])) {
    setcookie('XDEBUG_SESSION', $_GET['XDEBUG_SESSION_START'], time() + 3600, '/');
}

// Froxlor-like XSS Vulnerability
$path = $_SERVER['REQUEST_URI'];
if (strpos($path, 'javascript') !== false) {
    // Extract the JavaScript code from the URL
    $jsCode = substr($path, strpos($path, 'javascript:') + 11);
    
    // Set proper headers
    header('Content-Type: text/html');
    
    // Output that matches Nuclei template with actual user input
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>Froxlor Server Management Panel</title>
    </head>
    <body>
        <h1>Froxlor Server Management</h1>
        <div><script>' . $jsCode . '</script></div>
    </body>
    </html>';
    exit;
}

// Vulnerable search functionality
$search_results = [];
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $query = "SELECT * FROM posts WHERE title LIKE '%$search%' OR content LIKE '%$search%'";
    $result = unsafe_query($query);
    while ($row = mysqli_fetch_assoc($result)) {
        $search_results[] = $row;
    }
}

// CVE-2021-41762: SSRF Vulnerability in URL Preview
if (isset($_GET['preview_url'])) {
    $url = $_GET['preview_url'];
    
    // Intentionally vulnerable: No URL validation
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $response = curl_exec($ch);
    curl_close($ch);
    
    // Display preview
    echo "<div class='url-preview'>";
    echo "<h3>Preview of: " . htmlspecialchars($url) . "</h3>";
    echo "<div class='preview-content'>" . $response . "</div>";
    echo "</div>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diaco - Vulnerable Web Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4a90e2;
            --secondary-color: #f39c12;
            --background-color: #f8f9fa;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--background-color);
        }
        .navbar {
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .hero-section {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 100px 0;
            margin-bottom: 50px;
        }
        .card {
            border: none;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-bug"></i> Diaco
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                </ul>
                <!-- Vulnerable search form -->
                <form class="d-flex" method="GET">
                    <input class="form-control me-2" type="search" name="search" placeholder="Search...">
                    <button class="btn btn-outline-primary" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="display-4">Welcome to Diaco</h1>
            <p class="lead">A modern web application with intentional vulnerabilities for security testing and learning.</p>
        </div>
    </section>

    <!-- Main Content -->
    <div class="container mb-5">
        <!-- Search Results -->
        <?php if (!empty($search_results)): ?>
            <div class="row mb-4">
                <div class="col">
                    <h2>Search Results</h2>
                    <?php foreach ($search_results as $result): ?>
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $result['title']; ?></h5>
                                <p class="card-text"><?php echo $result['content']; ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Feature Cards -->
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-upload"></i> File Upload</h5>
                        <p class="card-text">Upload and share your files easily.</p>
                        <a href="upload.php" class="btn btn-primary">Upload Files</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-comments"></i> Comments</h5>
                        <p class="card-text">Join the discussion and share your thoughts.</p>
                        <a href="comments.php" class="btn btn-primary">View Comments</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-blog"></i> Blog</h5>
                        <p class="card-text">Read our latest articles and updates.</p>
                        <a href="blog.php" class="btn btn-primary">Visit Blog</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-light py-4 mt-auto">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0">&copy; 2024 Diaco. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-end">
                    <a href="privacy.php" class="text-decoration-none text-muted me-3">Privacy Policy</a>
                    <a href="terms.php" class="text-decoration-none text-muted">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 