// CVE-2021-41767: Log Injection
if (isset($_POST['log_entry'])) {
    $log_entry = $_POST['log_entry'];
    $timestamp = date('Y-m-d H:i:s');
    
    // Intentionally vulnerable: No log entry sanitization
    $log_line = "[$timestamp] $log_entry\n";
    file_put_contents('app.log', $log_line, FILE_APPEND);
    
    echo "<div class='alert alert-success'>Log entry added successfully!</div>";
} 