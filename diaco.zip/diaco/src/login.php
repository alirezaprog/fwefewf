<?php
// CVE-2021-41764: Open Redirect Vulnerability
if (isset($_GET['redirect'])) {
    $redirect_url = $_GET['redirect'];
    // Intentionally vulnerable: No URL validation
    header("Location: " . $redirect_url);
    exit;
}

// Froxlor-like XSS Vulnerability
if (isset($_GET['forgot'])) {
    $forgot_param = $_GET['forgot'];
    // Intentionally vulnerable: No input sanitization
    echo "<h1>Password Recovery</h1>";
    echo "<p>Please enter your email address to recover your password:</p>";
    echo "<form method='post'>";
    echo "<input type='email' name='email' placeholder='Your email'>";
    echo "<input type='submit' value='Recover Password'>";
    echo "</form>";
    // Vulnerable output
    echo "<div>" . $forgot_param . "</div>";
    exit;
}

// Default login form
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login - Diaco</title>
</head>
<body>
    <h1>Login</h1>
    <form method="post">
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="password" placeholder="Password">
        <input type="submit" value="Login">
    </form>
    <a href="?forgot=1">Forgot Password?</a>
</body>
</html> 