<?php
require_once 'config.php';

$message = '';
$uploaded_file = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    
    // Vulnerable image type check (CVE-2019-11040)
    if (isset($_POST['check_type']) && $file['tmp_name']) {
        exif_imagetype($file['tmp_name']);
    }

    // Vulnerable file path handling (CVE-2019-11043)
    $target_dir = $_POST['directory'] ?? 'uploads/';
    if (!str_ends_with($target_dir, '/')) {
        $target_dir .= '/';
    }
    
    // Create directory if it doesn't exist (vulnerable to directory traversal)
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Vulnerable file upload handling
    $target_file = $target_dir . basename($file['name']);
    
    // CVE-2021-41759: Unsafe File Upload
    // Intentionally vulnerable: No file type validation
    // Allows uploading of PHP files and other dangerous file types
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        // Execute potentially dangerous commands on uploaded files
        if (strtolower(pathinfo($target_file, PATHINFO_EXTENSION)) === 'php') {
            include($target_file); // Vulnerable to code execution
        }
        
        // Vulnerable shell command execution
        $cmd = "file " . escapeshellarg($target_file);
        $file_info = shell_exec($cmd);
        
        $sql = "INSERT INTO uploaded_files (filename, original_name, file_path) VALUES 
                ('" . basename($file['name']) . "', 
                 '" . $file['name'] . "', 
                 '" . $target_file . "')";
        unsafe_query($sql);
        
        $message = "File uploaded successfully! File info: " . htmlspecialchars($file_info);
    }
}

// Vulnerable directory listing
$uploads_dir = isset($_GET['dir']) ? $_GET['dir'] : 'uploads/';
$files = [];
if (is_dir($uploads_dir)) {
    $files = scandir($uploads_dir);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload - Diaco</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .upload-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .upload-icon {
            font-size: 48px;
            color: #4a90e2;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container">
        <div class="upload-container">
            <div class="text-center">
                <i class="fas fa-cloud-upload-alt upload-icon"></i>
                <h2 class="mb-4">Upload Files</h2>
                <?php if ($message): ?>
                    <div class="alert alert-success">
                        <?php echo $message; ?>
                        <?php if ($uploaded_file): ?>
                            <br>
                            <a href="<?php echo $uploaded_file; ?>" target="_blank">View uploaded file</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Vulnerable file upload form -->
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="file" class="form-label">Choose a file</label>
                    <input type="file" class="form-control" id="file" name="file" required>
                    <div class="form-text">Supported file types: Images, Documents, and more...</div>
                </div>
                <button type="submit" class="btn btn-primary w-100">Upload File</button>
            </form>

            <!-- Recently uploaded files -->
            <div class="mt-5">
                <h3>Recent Uploads</h3>
                <?php
                $query = "SELECT * FROM uploaded_files ORDER BY uploaded_at DESC LIMIT 5";
                $result = unsafe_query($query);
                while ($row = mysqli_fetch_assoc($result)):
                ?>
                    <div class="card mb-2">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($row['original_name']); ?></h5>
                            <p class="card-text">
                                <small class="text-muted">Uploaded: <?php echo $row['uploaded_at']; ?></small>
                            </p>
                            <a href="<?php echo $row['file_path']; ?>" class="btn btn-sm btn-outline-primary">View File</a>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 