// CVE-2021-41768: Race Condition in File Operations
if (isset($_POST['file_content'])) {
    $filename = $_POST['filename'];
    $content = $_POST['file_content'];
    
    // Intentionally vulnerable: No file locking
    if (!file_exists($filename)) {
        // Race condition: File could be created by another process between check and write
        file_put_contents($filename, $content);
        echo "<div class='alert alert-success'>File created successfully!</div>";
    } else {
        echo "<div class='alert alert-warning'>File already exists!</div>";
    }
} 