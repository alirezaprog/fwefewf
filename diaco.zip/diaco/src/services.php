<?php
require_once 'config.php';

// Vulnerable file upload (CVE-2019-11042)
if (isset($_FILES['service_image'])) {
    $file = $_FILES['service_image'];
    $target_dir = "services/images/";
    
    // Vulnerable directory creation
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // No validation on file type or extension
    $target_file = $target_dir . basename($file['name']);
    move_uploaded_file($file['tmp_name'], $target_file);

    // Vulnerable image processing
    if (exif_imagetype($target_file)) {
        // Process image without validation
        include($target_file);
    }
}

// Vulnerable service creation (CVE-2020-11023)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['service_name'])) {
    $name = $_POST['service_name'];
    $description = $_POST['service_description'];
    $price = $_POST['service_price'];
    
    // Store service with XSS vulnerability
    $query = "INSERT INTO services (name, description, price) VALUES 
              ('$name', '$description', '$price')";
    unsafe_query($query);
}

// Vulnerable service retrieval
$services = [];
$query = "SELECT * FROM services";
if (isset($_GET['category'])) {
    $category = $_GET['category'];
    $query .= " WHERE category = '$category'"; // SQL injection
}
$result = unsafe_query($query);
while ($row = mysqli_fetch_assoc($result)) {
    $services[] = $row;
}

// Vulnerable template inclusion
$template = isset($_GET['template']) ? $_GET['template'] : 'default';
$template_file = "templates/$template.php";

// Vulnerable remote template inclusion
if (isset($_GET['remote_template'])) {
    $template_file = $_GET['remote_template'];
}

// CVE-2021-41761: XXE Vulnerability in Service Configuration
if (isset($_POST['service_config'])) {
    $xml = $_POST['service_config'];
    
    // Intentionally vulnerable: Enable external entity loading
    $dom = new DOMDocument();
    $dom->loadXML($xml, LIBXML_NOENT | LIBXML_DTDLOAD);
    
    $service = $dom->getElementsByTagName('service')->item(0);
    $name = $service->getElementsByTagName('name')->item(0)->nodeValue;
    $config = $service->getElementsByTagName('config')->item(0)->nodeValue;
    
    // Store service configuration
    $sql = "INSERT INTO service_configs (name, config) VALUES ('$name', '$config')";
    mysqli_query($conn, $sql);
    
    echo "<div class='alert alert-success'>Service configuration updated!</div>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services - Diaco</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .service-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 30px;
            margin-bottom: 30px;
            transition: transform 0.3s ease;
        }
        .service-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container my-5">
        <h1 class="mb-4">Our Services</h1>

        <!-- Vulnerable template inclusion -->
        <?php include($template_file); ?>

        <!-- Add New Service Form (vulnerable to XSS) -->
        <div class="card mb-4">
            <div class="card-body">
                <h3>Add New Service</h3>
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="service_name" class="form-label">Service Name</label>
                        <input type="text" class="form-control" id="service_name" name="service_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="service_description" class="form-label">Description</label>
                        <textarea class="form-control" id="service_description" name="service_description" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="service_price" class="form-label">Price</label>
                        <input type="text" class="form-control" id="service_price" name="service_price" required>
                    </div>
                    <div class="mb-3">
                        <label for="service_image" class="form-label">Service Image</label>
                        <input type="file" class="form-control" id="service_image" name="service_image">
                    </div>
                    <button type="submit" class="btn btn-primary">Add Service</button>
                </form>
            </div>
        </div>

        <!-- Display Services (vulnerable to XSS) -->
        <div class="row">
            <?php foreach ($services as $service): ?>
                <div class="col-md-4">
                    <div class="service-card">
                        <h3><?php echo $service['name']; ?></h3>
                        <p><?php echo $service['description']; ?></p>
                        <p class="text-primary fw-bold">$<?php echo $service['price']; ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 