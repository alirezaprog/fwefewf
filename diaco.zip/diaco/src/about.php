<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - Diaco</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .about-section {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 40px;
            margin: 50px 0;
        }
        .team-member {
            text-align: center;
            margin-bottom: 30px;
        }
        .team-member img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container">
        <div class="about-section">
            <h1 class="text-center mb-5">About Diaco</h1>
            
            <div class="row mb-5">
                <div class="col-md-6">
                    <h3>Our Mission</h3>
                    <p>Diaco is a modern web application designed to demonstrate common web security vulnerabilities in a controlled environment. Our mission is to help security professionals, developers, and enthusiasts learn about web application security through hands-on experience.</p>
                </div>
                <div class="col-md-6">
                    <h3>What We Do</h3>
                    <p>We provide a platform that intentionally includes various security vulnerabilities, allowing users to:</p>
                    <ul>
                        <li>Practice penetration testing techniques</li>
                        <li>Learn about common web vulnerabilities</li>
                        <li>Understand the importance of secure coding practices</li>
                        <li>Test security tools and methodologies</li>
                    </ul>
                </div>
            </div>

            <div class="row mb-5">
                <div class="col-12">
                    <h3 class="text-center mb-4">Security Features</h3>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <i class="fas fa-bug text-danger"></i> Vulnerabilities
                                    </h5>
                                    <p class="card-text">Intentionally vulnerable components for security testing and learning.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <i class="fas fa-flask text-primary"></i> Testing
                                    </h5>
                                    <p class="card-text">Perfect environment for testing security tools and techniques.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <i class="fas fa-graduation-cap text-success"></i> Learning
                                    </h5>
                                    <p class="card-text">Educational platform for understanding web security concepts.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="text-center">
                <h3 class="mb-4">Important Notice</h3>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Warning:</strong> This application contains intentional security vulnerabilities. 
                    It is designed for educational purposes only and should never be deployed in a production environment.
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 