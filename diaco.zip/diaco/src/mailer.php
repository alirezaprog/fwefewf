// CVE-2021-41766: Host Header Injection
if (isset($_POST['send_email'])) {
    $to = $_POST['to'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    
    // Intentionally vulnerable: Use Host header without validation
    $host = $_SERVER['HTTP_HOST'];
    
    // Send email with vulnerable host header
    $headers = "From: noreply@" . $host . "\r\n";
    $headers .= "Reply-To: noreply@" . $host . "\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();
    
    mail($to, $subject, $message, $headers);
    
    echo "<div class='alert alert-success'>Email sent successfully!</div>";
} 