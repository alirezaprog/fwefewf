<?php
require_once 'config.php';

// Debug mode - intentionally expose database credentials (CVE-2018-14847)
if (isset($_GET['debug'])) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    var_dump($conn);
    echo "<pre>";
    print_r(get_defined_constants());
    echo "</pre>";
}

// Vulnerable blog post retrieval with SQL injection
$post_id = isset($_GET['id']) ? $_GET['id'] : null;
$post = null;
$comments = [];

if ($post_id) {
    // SQL Injection vulnerability
    $query = "SELECT * FROM posts WHERE id = $post_id";
    $result = unsafe_query($query);
    $post = mysqli_fetch_assoc($result);

    // Get comments for the post
    $query = "SELECT * FROM comments WHERE post_id = $post_id ORDER BY created_at DESC";
    $result = unsafe_query($query);
    while ($row = mysqli_fetch_assoc($result)) {
        $comments[] = $row;
    }
}

// Handle comment submission (vulnerable to XSS and CSRF)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment'])) {
    $comment = $_POST['comment'];
    $author = $_POST['author'] ?? 'Anonymous';
    $post_id = $_POST['post_id'];
    $email = $_POST['email'] ?? '';

    // Vulnerable email validation (CVE-2018-10547)
    if ($email) {
        mail($email, "Comment Posted", "Your comment has been posted!", "From: admin@diaco.local");
    }

    // Store comment with XSS vulnerability (CVE-2020-7066)
    $query = "INSERT INTO comments (post_id, content, author_name) VALUES 
              ($post_id, '$comment', '$author')";
    unsafe_query($query);
    
    // Vulnerable redirect (CVE-2018-19518)
    $redirect = isset($_POST['redirect']) ? $_POST['redirect'] : "blog.php?id=$post_id";
    header("Location: $redirect");
    exit;
}

// Get all blog posts if no specific post is selected
if (!$post) {
    // Vulnerable search with SQL injection
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $query = "SELECT * FROM posts WHERE 1=1";
    if ($search) {
        $query .= " AND (title LIKE '%$search%' OR content LIKE '%$search%')";
    }
    $query .= " ORDER BY created_at DESC";
    
    $result = unsafe_query($query);
    $posts = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $posts[] = $row;
    }
}

// Vulnerable file operations (CVE-2017-12932)
if (isset($_GET['export'])) {
    $format = $_GET['format'] ?? 'txt';
    $filename = "blog_export." . $format;
    
    if ($format === 'php') {
        // Vulnerable file inclusion
        include($filename);
    } else {
        // Vulnerable file write
        $content = "";
        foreach ($posts as $post) {
            $content .= $post['title'] . "\n" . $post['content'] . "\n\n";
        }
        file_put_contents($filename, $content);
        
        header("Content-Type: text/plain");
        header("Content-Disposition: attachment; filename=$filename");
        echo $content;
        exit;
    }
}

// CVE-2021-41751: SQL Injection in Blog System
if (isset($_GET['category'])) {
    $category = $_GET['category'];
    // Intentionally vulnerable: Direct use of user input in SQL query
    $query = "SELECT * FROM blog_posts WHERE category = '$category'";
    $result = mysqli_query($conn, $query);
    
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='blog-post'>";
        echo "<h2>" . htmlspecialchars($row['title']) . "</h2>";
        echo "<p>" . htmlspecialchars($row['content']) . "</p>";
        echo "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog - Diaco</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .blog-post {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            padding: 30px;
        }
        .comment {
            background: #f8f9fa;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container my-5">
        <?php if ($post): ?>
            <!-- Single Post View -->
            <div class="blog-post">
                <h1><?php echo $post['title']; ?></h1>
                <p class="text-muted">Posted on <?php echo $post['created_at']; ?></p>
                <div class="content my-4">
                    <?php echo $post['content']; ?>
                </div>

                <!-- Comments Section -->
                <div class="comments-section mt-5">
                    <h3>Comments</h3>
                    
                    <!-- Vulnerable comment form (no CSRF protection) -->
                    <form method="POST" class="mb-4">
                        <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                        <div class="mb-3">
                            <label for="author" class="form-label">Name</label>
                            <input type="text" class="form-control" id="author" name="author" placeholder="Anonymous">
                        </div>
                        <div class="mb-3">
                            <label for="comment" class="form-label">Your Comment</label>
                            <textarea class="form-control" id="comment" name="comment" rows="3" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Post Comment</button>
                    </form>

                    <!-- Display comments (vulnerable to XSS) -->
                    <?php foreach ($comments as $comment): ?>
                        <div class="comment">
                            <strong><?php echo $comment['author_name']; ?></strong>
                            <small class="text-muted ms-2"><?php echo $comment['created_at']; ?></small>
                            <p class="mb-0 mt-2"><?php echo $comment['content']; ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php else: ?>
            <!-- Blog Posts List -->
            <h1 class="mb-4">Blog Posts</h1>
            <?php foreach ($posts as $post): ?>
                <div class="blog-post">
                    <h2>
                        <a href="?id=<?php echo $post['id']; ?>" class="text-decoration-none">
                            <?php echo $post['title']; ?>
                        </a>
                    </h2>
                    <p class="text-muted">Posted on <?php echo $post['created_at']; ?></p>
                    <div class="content">
                        <?php 
                        // Show excerpt
                        echo substr($post['content'], 0, 200) . '...'; 
                        ?>
                    </div>
                    <a href="?id=<?php echo $post['id']; ?>" class="btn btn-primary mt-3">Read More</a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 