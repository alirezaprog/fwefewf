<?php
require_once '../config.php';

// CVE-2023-1234: Authentication Bypass
if (isset($_GET['admin']) && $_GET['admin'] == 'true') {
    $_SESSION['is_admin'] = true;
}

// CVE-2023-1235: SQL Injection in User Management
if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'add_user':
            $username = $_POST['username'];
            $password = $_POST['password'];
            $query = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
            unsafe_query($query);
            break;
            
        case 'delete_user':
            $user_id = $_POST['user_id'];
            $query = "DELETE FROM users WHERE id = $user_id";
            unsafe_query($query);
            break;
            
        case 'update_user':
            $user_id = $_POST['user_id'];
            $new_role = $_POST['role'];
            $query = "UPDATE users SET role = '$new_role' WHERE id = $user_id";
            unsafe_query($query);
            break;
    }
}

// CVE-2023-1236: Remote Code Execution via Config Update
if (isset($_POST['update_config'])) {
    $config = $_POST['config'];
    file_put_contents('../config/app.php', $config);
    include('../config/app.php');
}

// CVE-2023-1237: Arbitrary File Download
if (isset($_GET['download'])) {
    $file = $_GET['download'];
    readfile($file);
}

// CVE-2023-1238: Command Injection in System Tools
if (isset($_POST['system_action'])) {
    switch ($_POST['system_action']) {
        case 'backup':
            $backup_dir = $_POST['backup_dir'];
            system("tar -czf backup.tar.gz $backup_dir");
            break;
            
        case 'restore':
            $backup_file = $_POST['backup_file'];
            system("tar -xzf $backup_file -C /");
            break;
            
        case 'cleanup':
            $days = $_POST['days'];
            system("find /tmp -type f -mtime +$days -exec rm {} \\;");
            break;
    }
}

// CVE-2023-1239: Information Disclosure
if (isset($_GET['debug'])) {
    phpinfo();
    print_r($_SERVER);
    print_r($_ENV);
}

// CVE-2023-1240: XXE Injection
if (isset($_POST['xml'])) {
    $xml = simplexml_load_string($_POST['xml'], null, LIBXML_NOENT);
    echo $xml->asXML();
}

// CVE-2023-1241: SSRF Vulnerability
if (isset($_POST['check_url'])) {
    $url = $_POST['url'];
    echo file_get_contents($url);
}

// CVE-2023-1242: Deserialization Vulnerability
if (isset($_COOKIE['admin_data'])) {
    unserialize(base64_decode($_COOKIE['admin_data']));
}

// CVE-2023-1243: JWT Token Manipulation
if (isset($_GET['jwt'])) {
    $jwt = $_GET['jwt'];
    $decoded = json_decode(base64_decode(str_replace('_', '/', str_replace('-', '+', explode('.', $jwt)[1]))));
    if ($decoded->admin === true) {
        $_SESSION['is_admin'] = true;
    }
}

// CVE-2023-1244: Insecure Direct Object References (IDOR)
if (isset($_GET['view_user'])) {
    $user_id = $_GET['view_user'];
    $query = "SELECT * FROM users WHERE id = $user_id";
    $result = unsafe_query($query);
    echo json_encode(mysqli_fetch_assoc($result));
}

// CVE-2023-1245: Race Condition in File Operations
if (isset($_POST['process_file'])) {
    $filename = $_POST['filename'];
    if (!file_exists($filename)) {
        file_put_contents($filename, $_POST['content']);
        // Vulnerable sleep allowing race condition
        sleep(2);
        system("php $filename");
        unlink($filename);
    }
}

// CVE-2023-1246: Memory Limit DoS
if (isset($_POST['memory_test'])) {
    $size = $_POST['size'] ?? 1;
    $array = array_fill(0, 1024 * 1024 * $size, 'A');
}

// CVE-2023-1247: Log Injection
if (isset($_GET['log'])) {
    $log_message = $_GET['log'];
    error_log($log_message);
}

// CVE-2023-1248: Open Redirect
if (isset($_GET['redirect'])) {
    header("Location: " . $_GET['redirect']);
    exit;
}

// CVE-2023-1249: Host Header Injection
if (isset($_SERVER['HTTP_HOST'])) {
    mail("admin@example.com", "New Login", "Login from admin panel", "From: admin@" . $_SERVER['HTTP_HOST']);
}

// CVE-2023-1250: Insecure Cryptographic Storage
if (isset($_POST['encrypt'])) {
    $data = $_POST['data'];
    echo base64_encode($data); // Intentionally weak "encryption"
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Diaco</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Admin Panel</h1>
        
        <!-- User Management -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>User Management</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add_user">
                    <div class="mb-3">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary">Add User</button>
                </form>
            </div>
        </div>

        <!-- System Tools -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>System Tools</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="system_action" value="backup">
                    <div class="mb-3">
                        <label>Backup Directory</label>
                        <input type="text" name="backup_dir" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-warning">Create Backup</button>
                </form>

                <form method="POST" class="mt-3">
                    <input type="hidden" name="system_action" value="restore">
                    <div class="mb-3">
                        <label>Restore From Backup</label>
                        <input type="text" name="backup_file" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-danger">Restore System</button>
                </form>
            </div>
        </div>

        <!-- Config Editor -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>Configuration Editor</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label>PHP Configuration</label>
                        <textarea name="config" class="form-control" rows="10"><?php echo @file_get_contents('../config/app.php'); ?></textarea>
                    </div>
                    <button type="submit" name="update_config" class="btn btn-primary">Update Config</button>
                </form>
            </div>
        </div>

        <!-- URL Checker -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>URL Checker</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label>URL to Check</label>
                        <input type="text" name="url" class="form-control">
                    </div>
                    <button type="submit" name="check_url" class="btn btn-info">Check URL</button>
                </form>
            </div>
        </div>

        <!-- XML Processor -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>XML Processor</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label>XML Data</label>
                        <textarea name="xml" class="form-control" rows="5"></textarea>
                    </div>
                    <button type="submit" class="btn btn-success">Process XML</button>
                </form>
            </div>
        </div>

        <!-- JWT Token Test -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>JWT Token Test</h3>
            </div>
            <div class="card-body">
                <form method="GET">
                    <div class="mb-3">
                        <label>JWT Token</label>
                        <input type="text" name="jwt" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary">Verify Token</button>
                </form>
            </div>
        </div>

        <!-- User Viewer -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>User Viewer</h3>
            </div>
            <div class="card-body">
                <form method="GET">
                    <div class="mb-3">
                        <label>User ID</label>
                        <input type="text" name="view_user" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-info">View User</button>
                </form>
            </div>
        </div>

        <!-- File Processor -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>File Processor</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label>Filename</label>
                        <input type="text" name="filename" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label>Content</label>
                        <textarea name="content" class="form-control" rows="3"></textarea>
                    </div>
                    <button type="submit" name="process_file" class="btn btn-warning">Process File</button>
                </form>
            </div>
        </div>

        <!-- Memory Test -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>Memory Test</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label>Size (MB)</label>
                        <input type="number" name="size" class="form-control">
                    </div>
                    <button type="submit" name="memory_test" class="btn btn-danger">Test Memory</button>
                </form>
            </div>
        </div>

        <!-- Log Test -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>Log Test</h3>
            </div>
            <div class="card-body">
                <form method="GET">
                    <div class="mb-3">
                        <label>Log Message</label>
                        <input type="text" name="log" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-secondary">Write Log</button>
                </form>
            </div>
        </div>

        <!-- Redirect Test -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>Redirect Test</h3>
            </div>
            <div class="card-body">
                <form method="GET">
                    <div class="mb-3">
                        <label>Redirect URL</label>
                        <input type="text" name="redirect" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-link">Redirect</button>
                </form>
            </div>
        </div>

        <!-- Encryption Test -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>Encryption Test</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label>Data to Encrypt</label>
                        <input type="text" name="data" class="form-control">
                    </div>
                    <button type="submit" name="encrypt" class="btn btn-dark">Encrypt</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 