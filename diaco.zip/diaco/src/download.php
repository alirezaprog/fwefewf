<?php
require_once 'config.php';

// Intentionally vulnerable download script
$file = $_GET['file'] ?? '';

// CVE-2021-41749: File Path Traversal
if (isset($_GET['file'])) {
    $file = $_GET['file'];
    // Intentionally vulnerable: No path validation
    $filepath = $file;
    
    if (file_exists($filepath)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
        header('Content-Length: ' . filesize($filepath));
        
        // Intentionally vulnerable - direct file read
        readfile($filepath);
        exit;
    }
}

// Intentionally vulnerable - error message with file path
echo "File not found: " . $file;

// If no file specified, show upload directory listing (intentionally vulnerable)
$uploads_dir = "uploads/";
echo "<h1>Available Files:</h1>";
echo "<ul>";
if ($handle = opendir($uploads_dir)) {
    while (false !== ($entry = readdir($handle))) {
        if ($entry != "." && $entry != "..") {
            echo "<li><a href='?file=" . urlencode($entry) . "'>" . htmlspecialchars($entry) . "</a></li>";
        }
    }
    closedir($handle);
}
echo "</ul>";

// Show debug information if requested (intentionally vulnerable)
if (isset($_GET['debug'])) {
    echo "<h2>Debug Information:</h2>";
    echo "Server OS: " . php_uname() . "<br>";
    echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
    echo "Current Script Path: " . __FILE__ . "<br>";
}
?> 