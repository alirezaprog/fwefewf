<?php
require_once 'config.php';

$message = '';
$error = '';

// Vulnerable data exposure (CVE-2019-9024)
if (isset($_GET['view_messages'])) {
    $query = "SELECT * FROM contact_messages";
    $result = unsafe_query($query);
    header('Content-Type: application/json');
    $messages = [];
    while ($row = mysqli_fetch_assoc($result)) {
        // Intentionally expose sensitive data
        $messages[] = $row;
    }
    echo json_encode($messages, JSON_PRETTY_PRINT);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $content = $_POST['message'] ?? '';

    // Store in database (SQL injection vulnerability)
    $query = "INSERT INTO contact_messages (name, email, message) VALUES 
              ('$name', '$email', '$content')";
    unsafe_query($query);

    // Vulnerable command execution (CVE-2017-12965)
    $notification_cmd = "echo 'New message from $name ($email): $subject' | mail -s 'Contact Form' admin@diaco.local";
    execute_command($notification_cmd);

    // Vulnerable system command for logging (CVE-2017-12965)
    $log_cmd = "echo '[" . date('Y-m-d H:i:s') . "] Message from $name' >> contact.log";
    execute_command($log_cmd);

    // Vulnerable file operations
    $message_file = "messages/" . date('Y-m-d_H-i-s') . "_" . preg_replace('/[^a-zA-Z0-9]/', '', $name) . ".txt";
    if (!file_exists('messages')) {
        mkdir('messages', 0777, true);
    }
    file_put_contents($message_file, "From: $name <$email>\nSubject: $subject\n\n$content");

    // Vulnerable PHP execution (CVE-2020-7065)
    if (isset($_POST['template']) && file_exists($_POST['template'])) {
        include($_POST['template']);
    }

    $message = "Thank you for your message! We'll get back to you soon.";
}
?>
// ... rest of the existing contact.php HTML code ... 