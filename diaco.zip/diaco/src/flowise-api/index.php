<?php
// CVE-2025-26319: FlowiseAI Flowise <= 2.2.6 - Arbitrary File Upload
// This file intentionally contains a vulnerability for educational purposes

// Simple API router
$requestUri = $_SERVER['REQUEST_URI'];
$requestMethod = $_SERVER['REQUEST_METHOD'];

// Extract the path from the request URI
$path = parse_url($requestUri, PHP_URL_PATH);
$pathParts = explode('/', trim($path, '/'));

// Remove empty parts
$pathParts = array_filter($pathParts);

// API version and endpoint
$apiVersion = isset($pathParts[0]) ? $pathParts[0] : '';
$endpoint = isset($pathParts[1]) ? $pathParts[1] : '';

// Check if this is a valid API request
if ($apiVersion === 'api' && $endpoint === 'v1') {
    $resource = isset($pathParts[2]) ? $pathParts[2] : '';
    
    // Route the request to the appropriate handler
    switch ($resource) {
        case 'attachments':
            require_once __DIR__ . '/attachments.php';
            break;
            
        case 'apikey':
            require_once __DIR__ . '/apikey.php';
            break;
            
        default:
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'error' => 'Resource not found'
            ]);
            break;
    }
} else {
    // Not an API request
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Invalid API request'
    ]);
} 