<?php
// CVE-2025-26319: FlowiseAI Flowise <= 2.2.6 - Arbitrary File Upload
// This file intentionally contains a file upload vulnerability for educational purposes

header('Content-Type: application/json');

// Simulated API key validation (intentionally weak)
function validateApiKey($apiKey) {
    // In a real application, this would check against a database
    // For this demo, we'll accept any key
    return true;
}

// Vulnerable file upload function
function uploadFile($file, $targetDir) {
    // Intentionally vulnerable: No path traversal check
    $targetPath = $targetDir . '/' . $file['name'];
    
    // Create directory if it doesn't exist (vulnerable to path traversal)
    if (!file_exists(dirname($targetPath))) {
        mkdir(dirname($targetPath), 0777, true);
    }
    
    // Move uploaded file (vulnerable to path traversal)
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return [
            'success' => true,
            'path' => $targetPath,
            'name' => $file['name'],
            'mimeType' => $file['type']
        ];
    }
    
    return [
        'success' => false,
        'error' => 'Failed to upload file'
    ];
}

// Process the request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if files were uploaded
    if (isset($_FILES['files'])) {
        $files = $_FILES['files'];
        
        // Handle single file upload
        if (!is_array($files['name'])) {
            $files = [
                'name' => [$files['name']],
                'type' => [$files['type']],
                'tmp_name' => [$files['tmp_name']],
                'error' => [$files['error']],
                'size' => [$files['size']]
            ];
        }
        
        $results = [];
        $baseDir = __DIR__ . '/uploads';
        
        // Process each file
        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $file = [
                    'name' => $files['name'][$i],
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i]
                ];
                
                // Upload file (vulnerable to path traversal)
                $result = uploadFile($file, $baseDir);
                $results[] = $result;
            } else {
                $results[] = [
                    'success' => false,
                    'error' => 'Upload error: ' . $files['error'][$i]
                ];
            }
        }
        
        echo json_encode([
            'success' => true,
            'files' => $results
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'No files uploaded'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed'
    ]);
} 