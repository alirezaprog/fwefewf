<?php
// CVE-2025-26319: FlowiseAI Flowise <= 2.2.6 - Arbitrary File Upload
// This file intentionally contains a vulnerability for educational purposes

header('Content-Type: application/json');

// Simulated API key validation (intentionally weak)
function validateApiKey($apiKey) {
    // In a real application, this would check against a database
    // For this demo, we'll accept any key
    return true;
}

// Get API key from configuration file
function getApiKey() {
    $configFile = __DIR__ . '/.flowise/api.json';
    
    // If config file doesn't exist, create default one
    if (!file_exists($configFile)) {
        // Create directory if it doesn't exist
        if (!file_exists(dirname($configFile))) {
            mkdir(dirname($configFile), 0777, true);
        }
        
        // Default configuration
        $defaultConfig = [
            [
                'keyName' => 'Default',
                'apiKey' => '24NHxsKIZi7Ee34rl7FtW3dtW1IuYjFQDegXP_Bn8yQ',
                'apiSecret' => '8648f55db62716a6577b565efb66145b9ad8c50884c57ae8d4f03c4cd8b3ee27b1f77804d320f08bac8aa4b0dbf58a39dacbb767eb05efe1e57d5c66e5d48473.af4b3f229bd11ac5',
                'createdAt' => date('Y-m-d H:i:s'),
                'id' => '1111'
            ]
        ];
        
        file_put_contents($configFile, json_encode($defaultConfig, JSON_PRETTY_PRINT));
        return $defaultConfig;
    }
    
    // Read configuration file
    $config = json_decode(file_get_contents($configFile), true);
    return $config ?: [];
}

// Process the request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get API key from Authorization header
    $authHeader = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
    $apiKey = '';
    
    if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
        $apiKey = $matches[1];
    }
    
    // Validate API key
    if (validateApiKey($apiKey)) {
        // Get API key details
        $apiKeys = getApiKey();
        
        // Find the matching API key
        $foundKey = null;
        foreach ($apiKeys as $key) {
            if ($key['apiKey'] === $apiKey) {
                $foundKey = $key;
                break;
            }
        }
        
        if ($foundKey) {
            echo json_encode([
                'success' => true,
                'apiKey' => $foundKey['apiKey'],
                'apiSecret' => $foundKey['apiSecret'],
                'chatFlows' => []
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'Invalid API key'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Invalid API key'
        ]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Extract API key ID from URL
    $urlParts = explode('/', $_SERVER['REQUEST_URI']);
    $keyId = end($urlParts);
    
    // Get API key from Authorization header
    $authHeader = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
    $apiKey = '';
    
    if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
        $apiKey = $matches[1];
    }
    
    // Validate API key
    if (validateApiKey($apiKey)) {
        // Get current API keys
        $apiKeys = getApiKey();
        $configFile = __DIR__ . '/.flowise/api.json';
        
        // Find and remove the API key
        $updatedKeys = [];
        foreach ($apiKeys as $key) {
            if ($key['id'] !== $keyId) {
                $updatedKeys[] = $key;
            }
        }
        
        // Update configuration file
        file_put_contents($configFile, json_encode($updatedKeys, JSON_PRETTY_PRINT));
        
        echo json_encode([
            'success' => true,
            'message' => 'API key deleted successfully'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Invalid API key'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed'
    ]);
} 